import os
import re
from PIL import Image
import asyncio
import logging
import traceback
import threading
import subprocess
import random
import shlex
import uuid, shutil
import asyncio 
import sys
from datetime import datetime
from base64 import urlsafe_b64encode, urlsafe_b64decode
from math import floor
from time import time
from random import choice
from asyncio import sleep as asleep
import aiohttp
import anitopy
from pyrogram import Client, filters, idle
from pyrogram.enums import ParseMode, ChatMemberStatus
from pyrogram.errors import FloodWait, PeerIdInvalid, ChannelInvalid, UserNotParticipant, QueryIdInvalid, MessageIdInvalid
from pyrogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    Message,
    CallbackQuery
)
import html
from typing import Dict, List, Tuple, Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
API_ID = 28015531
API_HASH = "2ab4ba37fd5d9ebf1353328fc915ad28"
BOT_TOKEN = "8267334379:AAH2TQwGb7bksodT2GQR4Fw8G22KQcnLeho"
TARGET_CHANNEL = current_target_channel = None
DB_CHANNEL = -1003093042498
UPDATE_CHANNEL = -1002121507999
UPDATE_CHANNEL_ENABLED = True
FILE_STORE = DB_CHANNEL
OWNER_ID = 6121610691
DELETE_DELAY = 30 * 60
DOWNLOAD_WORKERS = 4
BRAND_UNAME = "ATXanime"
MAX_CONCURRENT_ENCODINGS = 1

# Start message configuration
START_IMAGE_URL = "https://files.catbox.moe/zsz2xe.jpg"
ABOUT_TEXT = (
    "<blockquote><b>📇 A B O U T :</b>\n\n"
    "<b>‣ Language: Python</b>\n"
    "<b>‣ Hosted On: VPS</b>\n"
    "<b>‣ Main Channel: <a href=\"https://t.me/ATXanime\">ATXanime</a></b>\n"
    "<b>‣ Source Code: <a href=\"https://github.com/Asabeneh/30-Days-Of-Python\">GitHub</a></b>\n\n"
    "<b>👑 Developer: @ATXanime</b></blockquote>"
)

app = Client(
    "vihsdeouhiyvploander",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    workers=DOWNLOAD_WORKERS
)

# Detect hardware acceleration
HAS_NVIDIA = False
try:
    subprocess.check_output(['nvidia-smi'], stderr=subprocess.STDOUT)
    HAS_NVIDIA = True
    logger.info("NVIDIA GPU detected - enabling hardware acceleration")
except Exception:
    logger.info("No NVIDIA GPU detected - using software encoding")

# OPTIMIZED FFmpeg commands with proper hardware encoding
DEFAULT_FFMPEG_COMMANDS = {
    "480p": "ffmpeg -hwaccel cuda -hwaccel_output_format cuda -i {input} -c:v hevc_nvenc -preset p7 -b:v 800k -maxrate 1000k -bufsize 2000k -vf scale=854:480 -c:a copy -c:s copy -y {output}",
    "720p": "ffmpeg -hwaccel cuda -hwaccel_output_format cuda -i {input} -c:v hevc_nvenc -preset p7 -b:v 1500k -maxrate 2000k -bufsize 3000k -vf scale=1280:720 -c:a copy -c:s copy -y {output}",
    "1080p": "ffmpeg -hwaccel cuda -hwaccel_output_format cuda -i {input} -c:v hevc_nvenc -preset p7 -b:v 3000k -maxrate 4000k -bufsize 6000k -vf scale=1920:1080 -c:a copy -c:s copy -y {output}"
}

SOFTWARE_FFMPEG_COMMANDS = {
    "480p": "ffmpeg -i {input} -c:v libx265 -preset ultrafast -crf 28 -b:v 800k -maxrate 1000k -bufsize 2000k -vf scale=854:480 -c:a copy -c:s copy -y {output}",
    "720p": "ffmpeg -i {input} -c:v libx265 -preset ultrafast -crf 26 -b:v 1500k -maxrate 2000k -bufsize 3000k -vf scale=1280:720 -c:a copy -c:s copy -y {output}",
    "1080p": "ffmpeg -i {input} -c:v libx265 -preset ultrafast -crf 24 -b:v 3000k -maxrate 4000k -bufsize 6000k -vf scale=1920:1080 -c:a copy -c:s copy -y {output}"
}

# Use appropriate commands based on hardware
FFMPEG_COMMANDS = DEFAULT_FFMPEG_COMMANDS if HAS_NVIDIA else SOFTWARE_FFMPEG_COMMANDS

# Add metadata command
METADATA_FFMPEG_COMMAND = (
    "ffmpeg -hwaccel cuda -hwaccel_output_format cuda -i {input} "
    "-c:v copy -c:a copy -c:s copy "
    '-metadata title="{metadata}" -metadata:s:v title="{metadata}" '
    '-metadata:s:a title="{metadata}" -metadata:s:s title="{metadata}" -y {output}'
) if HAS_NVIDIA else (
    "ffmpeg -i {input} -c:v copy -c:a copy -c:s copy "
    '-metadata title="{metadata}" -metadata:s:v title="{metadata}" '
    '-metadata:s:a title="{metadata}" -metadata:s:s title="{metadata}" -y {output}'
)

THUMBNAIL_PATH = "thumb.jpg"

# Anime Information Formatting
CAPTION_FORMAT = """
<blockquote><b>➤ {title}</b></blockquote>
<b>────────────────</b>
<b>‣ Season : {season}</b>
<b>‣ Episode : {ep_no}</b>
<b>‣ Language : {language}</b>
<b>‣ Codec : {codec}</b>
<b>‣ Genres : {genres}</b>
<b>‣ Quality : {quality}</b>
<b>────────────────</b>
"""

GENRES_EMOJI = {
    "Action": "👊", 
    "Adventure": choice(['🪂', '🧗‍♀']), 
    "Comedy": "🤣", 
    "Drama": "🎭", 
    "Ecchi": choice(['💋', '🥵']), 
    "Fantasy": choice(['🧞', '🧞‍♂', '🧞‍♀','🌗']), 
    "Hentai": "🔞", 
    "Horror": "☠", 
    "Mahou Shoujo": "☯", 
    "Mecha": "🤖", 
    "Music": "🎸", 
    "Mystery": "🔮", 
    "Psychological": "♟", 
    "Romance": "💞", 
    "Sci-Fi": "🛸", 
    "Slice of Life": choice(['☘','🍁']), 
    "Sports": "⚽️", 
    "Supernatural": "🫧", 
    "Thriller": choice(['🥶', '🔪','🤯'])
}

ANIME_GRAPHQL_QUERY = """
query ($id: Int, $search: String, $seasonYear: Int) {
  Media(id: $id, type: ANIME, format_not_in: [MOVIE, MUSIC, MANGA, NOVEL, ONE_SHOT], search: $search, seasonYear: $seasonYear) {
    id
    idMal
    title {
      romaji
      english
      native
    }
    type
    format
    status(version: 2)
    description(asHtml: false)
    startDate {
      year
      month
      day
    }
    endDate {
      year
      month
      day
    }
    season
    seasonYear
    episodes
    duration
    chapters
    volumes
    countryOfOrigin
    source
    hashtag
    trailer {
      id
      site
      thumbnail
    }
    updatedAt
    coverImage {
      large
    }
    bannerImage
    genres
    synonyms
    averageScore
    meanScore
    popularity
    trending
    favourites
    studios {
      nodes {
         name
         siteUrl
      }
    }
    isAdult
    nextAiringEpisode {
      airingAt
      timeUntilAiring
      episode
    }
    airingSchedule {
      edges {
        node {
          airingAt
          timeUntilAiring
          episode
        }
      }
    }
    externalLinks {
      url
      site
    }
    siteUrl
  }
}
"""

# Button formatters
btn_formatter = {
    '480p': '𝟰𝟴𝟬𝗽',
    '720p': '𝟳𝟮𝟬𝗽',
    '1080p': '𝟭𝟬𝟴𝟬𝗽'
}

# Global variables
user_sessions = {}
file_messages_to_delete = {}
force_sub_channels = []
temp_force_sub_data = {}
cancel_requests = {}
ani_cache = {}  # Cache for AniList data
encoding_queue = asyncio.Queue()
processing_lock = asyncio.Lock()
metadata_settings = {}  # user_id: {"enabled": bool, "code": str}
queue_enabled = True  # Global queue enabled flag
processing_tasks = {}  # Track active processing tasks
active_encodings = 0  # Count of currently running encoding tasks
queue_status_messages = {}  # Track status messages for queue
channel_invite_links = {}  # Cache for channel invite links
# Store user-specific thumbnails
user_thumbnails = {}  # user_id: file_path
# Store custom FFmpeg commands
custom_ffmpeg_commands = {}  # user_id: {"480p": cmd, "720p": cmd, "1080p": cmd}
# Multi-mode settings - DEFAULT TO NORMAL MODE
multi_mode_settings = {7524367335: {"enabled": False, "source_file": None}}  # Default to normal mode

# Season/Episode patterns
SEASON_EPISODE_PATTERNS = [
    re.compile(r'[Ss](\d+)[\s\-]*[Ee]?[Pp]?(\d+)'), 
    re.compile(r'[Ss]eason\s*(\d+)\s*[Ee]pisode\s*(\d+)', re.IGNORECASE),
    re.compile(r'\[[Ss](\d+)\]\[[Ee]?[Pp]?(\d+)\]', re.IGNORECASE),
    re.compile(r'(\d+)[xX](\d+)'),
    re.compile(r'\b[Ee][Pp]?\s*(\d+)\b')
]

# Utility functions
def convert_bytes(size: int) -> str:
    if size == 0:
        return "0 B"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f"{size:.2f} {unit}"
        size /= 1024
    return f"{size:.2f} TB"

def convert_time(seconds: float) -> str:
    if seconds < 0:
        return "00:00:00"
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

def encode(data: str) -> str:
    return urlsafe_b64encode(data.encode()).decode().rstrip('=')

def decode(encoded_str: str) -> str:
    padding = '=' * (-len(encoded_str) % 4)
    return urlsafe_b64decode(encoded_str + padding).decode()

def extract_season_episode(filename: str) -> Tuple[Optional[str], Optional[str]]:
    for pattern in SEASON_EPISODE_PATTERNS:
        match = pattern.search(filename)
        if match:
            season = match.group(1)
            episode = match.group(2) if len(match.groups()) > 1 else None
            logger.info(f"Extracted season: {season}, episode: {episode} from {filename}")
            return season, episode
    logger.warning(f"No season/episode pattern matched for {filename}")
    return None, None

def extract_anime_info(filename: str) -> Tuple[str, Optional[str], Optional[str], Optional[str]]:
    season, episode = extract_season_episode(filename)
    
    quality = None
    quality_match = re.search(r'\[?\b(480p|720p|1080p)\b\]?', filename, re.IGNORECASE)
    if quality_match:
        quality = quality_match.group(1).lower()
    
    anime_name = filename
    
    # Remove quality string
    if quality:
        anime_name = re.sub(r'\[?\b' + quality + r'\b\]?', '', anime_name, flags=re.IGNORECASE)
    
    # Remove season/episode patterns
    for pattern in SEASON_EPISODE_PATTERNS:
        anime_name = pattern.sub('', anime_name)
    
    # Remove technical tags and unwanted parts
    tech_tags = [
        r'\[.*?\]', r'\(.*?\)', r'\bWEB-DL\b', r'\bx\d+\b', r'\bCR\b', r'\bESubs\b', 
        r'_\w+_', r'\b\d+kbps\b', r'\b\d+\.\d+\b', r'\bAAC\b', r'\bHEVC\b', r'\bH\.264\b',
        r'\b\w*subs?\w*\b', r'\b\w*dub\w*\b', r'\bATX\b', r'\bAnimeKurrollu\b', 
        r'Japanese', r'English', r'Hindi', r'Tamil', r'Telugu', r'[+\-]',
        r'\bH\s*\.?\s*264\b', r'\bH\s*\.?\s*265\b', r'\bHEVC\b', r'\bx264\b', r'\bx265\b',
        r'\b\d{3,4}p\b', r'\bHD\b', r'\bFHD\b', r'\bUHD\b', r'\bHQ\b', r'\bBluRay\b',
        r'\bWEBRip\b', r'\bBDRip\b', r'\bDual\s*Audio\b', r'\bMulti\s*Audio\b', r'\bSubbed\b',
        r'\bDubbed\b', r'\bUNCENSORED\b', r'\bREMUX\b', r'\bPROPER\b', r'\bREPACK\b'
    ]
    for tag in tech_tags:
        anime_name = re.sub(tag, '', anime_name, flags=re.IGNORECASE)
    
    # Clean special characters and extra spaces
    anime_name = re.sub(r'[^\w\s]', ' ', anime_name)
    anime_name = re.sub(r'\s+', ' ', anime_name).strip()
    
    # Remove file extension
    anime_name = re.sub(r'\.[^.]+$', '', anime_name)
    
    # Remove episode titles and trailing numbers
    anime_name = re.sub(r' - .*$', '', anime_name).strip()
    anime_name = re.sub(r'Episode \d+$', '', anime_name, flags=re.IGNORECASE).strip()
    anime_name = re.sub(r'\d+$', '', anime_name).strip()
    
    # Final cleanup
    anime_name = re.sub(r'\b(?:S\d+\s*)?E\d+\b', '', anime_name, flags=re.IGNORECASE).strip()
    anime_name = re.sub(r'[_-]+', ' ', anime_name).strip()
    
    logger.info(f"Cleaned anime name: {anime_name}")
    return anime_name, season, episode, quality

# AniList API Integration
class AniLister:
    def __init__(self, anime_name: str, year: int) -> None:
        self.__api = "https://graphql.anilist.co"
        self.__ani_name = anime_name
        self.__ani_year = year
        self.__vars = {'search' : self.__ani_name, 'seasonYear': self.__ani_year}
    
    def __update_vars(self, year: bool = True) -> None:
        if year:
            self.__ani_year -= 1
            self.__vars['seasonYear'] = self.__ani_year
        else:
            self.__vars = {'search' : self.__ani_name}
    
    async def post_data(self) -> Tuple[int, dict, dict]:
        async with aiohttp.ClientSession() as sess:
            async with sess.post(self.__api, json={'query': ANIME_GRAPHQL_QUERY, 'variables': self.__vars}) as resp:
                return (resp.status, await resp.json(), resp.headers)
        
    async def get_anidata(self) -> dict:
        # Check cache first
        cache_key = f"{self.__ani_name}-{self.__ani_year}"
        if cache_key in ani_cache:
            return ani_cache[cache_key]
            
        res_code, resp_json, res_heads = await self.post_data()
        if res_code == 200:
            ani_data = resp_json.get('data', {}).get('Media', {}) or {}
            # Cache successful response
            if ani_data:
                ani_cache[cache_key] = ani_data
            return ani_data
            
        # Retry logic for 404
        retry_count = 0
        while res_code == 404 and self.__ani_year > 2020 and retry_count < 3:
            self.__update_vars()
            logger.warning(f"AniList Query Name: {self.__ani_name}, Retrying with {self.__ani_year}")
            res_code, resp_json, res_heads = await self.post_data()
            if res_code == 200:
                ani_data = resp_json.get('data', {}).get('Media', {}) or {}
                if ani_data:
                    ani_cache[cache_key] = ani_data
                return ani_data
            retry_count += 1
        
        # Final try without year
        if res_code == 404:
            self.__update_vars(year=False)
            res_code, resp_json, res_heads = await self.post_data()
            if res_code == 200:
                ani_data = resp_json.get('data', {}).get('Media', {}) or {}
                if ani_data:
                    ani_cache[cache_key] = ani_data
                return ani_data
        
        # Handle rate limiting
        if res_code == 429:
            f_timer = int(res_heads.get('Retry-After', 60))
            logger.error(f"AniList API FloodWait: {res_code}, Sleeping for {f_timer} seconds")
            await asleep(f_timer)
            return await self.get_anidata()
            
        # Handle server errors
        if res_code in [500, 501, 502]:
            logger.error(f"AniList Server API Error: {res_code}, Waiting 5s to Try Again")
            await asleep(5)
            return await self.get_anidata()
            
        logger.error(f"AniList API Error: {res_code}")
        return {}

class TextEditor:
    def __init__(self, name):
        self.__name = name
        self.adata = {}
        self.pdata = anitopy.parse(name)

    async def load_anilist(self):
        # First try without season and without year
        ani_name = await self.parse_name(no_s=True, no_y=True)
        self.adata = await AniLister(ani_name, datetime.now().year).get_anidata()
        if self.adata:
            return
            
        # Then try with season but without year
        ani_name = await self.parse_name(no_s=False, no_y=True)
        self.adata = await AniLister(ani_name, datetime.now().year).get_anidata()
        if self.adata:
            return
            
        # Then try without season but with year
        ani_name = await self.parse_name(no_s=True, no_y=False)
        self.adata = await AniLister(ani_name, datetime.now().year).get_anidata()
        if self.adata:
            return
            
        # Finally try with season and year
        ani_name = await self.parse_name(no_s=False, no_y=False)
        self.adata = await AniLister(ani_name, datetime.now().year).get_anidata()

    async def parse_name(self, no_s=False, no_y=False):
        anime_name = self.pdata.get("anime_title")
        anime_season = self.pdata.get("anime_season")
        anime_year = self.pdata.get("anime_year")
        if anime_name:
            pname = anime_name
            if not no_s and self.pdata.get("episode_number") and anime_season:
                pname += f" {anime_season}"
            if not no_y and anime_year:
                pname += f" {anime_year}"
            return pname
        return anime_name
        
    async def get_id(self):
        if (ani_id := self.adata.get('id')) and str(ani_id).isdigit():
            return ani_id
            
    async def get_poster(self):
        if anime_id := await self.get_id():
            return f"https://img.anili.st/media/{anime_id}"
        return "https://telegra.ph/file/112ec08e59e73b6189a20.jpg"
    
    async def get_title(self):
        """Get the proper anime title from AniList data"""
        if self.adata:
            titles = self.adata.get('title', {})
            return titles.get('english') or titles.get('romaji') or titles.get('native')
        return self.pdata.get("anime_title") or os.path.splitext(self.__name)[0]
    
    async def get_season(self):
        """Get formatted season number"""
        season = self.pdata.get('anime_season', '01')
        return str(season).zfill(2) if season and str(season).isdigit() else '01'
    
    async def get_episode(self):
        """Get formatted episode number"""
        episode = self.pdata.get('episode_number', '01')
        return str(episode).zfill(2) if episode and str(episode).isdigit() else '01'
    
    async def get_formatted_name(self, quality, include_brand=True):
        """Generate the complete formatted filename"""
        title = await self.get_title()
        season = await self.get_season()
        episode = await self.get_episode()
        
        # Clean title for filename
        clean_title = re.sub(r'[\\/*?:"<>|]', "", title)  # Remove invalid characters
        clean_title = re.sub(r'\s+', ' ', clean_title).strip()
        
        # Conditionally include brand name
        brand_part = f" @{BRAND_UNAME}" if include_brand else ""
        return f"{clean_title} [S{season}][E{episode}][{quality}]Tamil HEVC{brand_part}.mkv"

    async def get_caption(self, language, codec, quality):
        title = await self.get_title()
        season = await self.get_season()
        episode = await self.get_episode()
        genres = self.adata.get('genres') or []
        formatted_genres = ", ".join(genres)
        
        return CAPTION_FORMAT.format(
            title=title,
            season=season,
            ep_no=episode,
            language=language,
            codec=codec,
            genres=formatted_genres,
            quality=quality
        )

async def create_download_link(msg_id):
    bot_username = (await app.get_me()).username
    encoded_str = encode(f'get-{str(msg_id * abs(FILE_STORE))}')
    return f"https://telegram.me/{bot_username}?start={encoded_str}"

async def delete_messages_after_delay(chat_id, message_ids, delay):
    await asyncio.sleep(delay)
    try:
        await app.delete_messages(chat_id, message_ids)
        logger.info(f"Deleted messages: {message_ids} in chat {chat_id}")
    except Exception as e:
        logger.error(f"Error deleting messages: {e}")

async def check_user_subscription(user_id):
    if not force_sub_channels:
        return True
    
    for channel_id in force_sub_channels:
        try:
            member = await app.get_chat_member(channel_id, user_id)
            if member.status in [ChatMemberStatus.LEFT, ChatMemberStatus.BANNED]:
                return False
        except UserNotParticipant:
            return False
        except Exception as e:
            logger.error(f"Error checking subscription for {user_id} in {channel_id}: {e}")
            return False
    return True

async def safe_delete_message(message: Message, delay: int = 5) -> None:
    await asyncio.sleep(delay)
    try:
        await message.delete()
    except (MessageIdInvalid, Exception) as e:
        logger.error(f"Error deleting message: {e}")

async def safe_edit_message(message: Message, text: str, parse_mode: ParseMode = ParseMode.HTML) -> bool:
    try:
        await message.edit_text(text, parse_mode=parse_mode)
        return True
    except MessageIdInvalid:
        logger.warning("MessageIdInvalid when editing message")
        return False
    except Exception as e:
        logger.error(f"Error editing message: {e}")
        return False

async def safe_answer_callback(callback_query: CallbackQuery, text: str, show_alert: bool = False) -> None:
    try:
        await callback_query.answer(text, show_alert=show_alert)
    except QueryIdInvalid:
        logger.warning("QueryIdInvalid when answering callback")
    except Exception as e:
        logger.error(f"Error answering callback: {e}")

async def create_persistent_invite_link(channel_id: int) -> str:
    global channel_invite_links
    
    # Check cache first
    if channel_id in channel_invite_links:
        return channel_invite_links[channel_id]
    
    try:
        # Create a new invite link that never expires
        invite = await app.create_chat_invite_link(
            channel_id,
            name="ATXanime Bot Link",
            expire_date=None,
            member_limit=None
        )
        channel_invite_links[channel_id] = invite.invite_link
        return invite.invite_link
    except Exception as e:
        logger.error(f"Error creating persistent invite link: {e}")
        try:
            # Fallback to existing link
            chat = await app.get_chat(channel_id)
            channel_invite_links[channel_id] = chat.invite_link
            return chat.invite_link
        except Exception as e:
            logger.error(f"Error getting existing invite link: {e}")
            return f"https://t.me/c/{str(channel_id).replace('-100', '')}"

class FileProcessor:
    def __init__(self, client, message: Message, rep: Message, file_path: str, 
                 quality: str, status_message: Optional[Message] = None, 
                 user_id: Optional[int] = None, metadata_code: Optional[str] = None):
        self.__client = client
        self.message = message
        self.rep = rep
        self.cancelled = False
        self.__start = time()
        self.__updater = self.__start
        self.__name = os.path.basename(file_path)
        self.quality = quality
        self.file_path = file_path
        self.encoding_start = 0
        self.status_message = status_message
        self.status_msg = None
        self.download_start = 0
        self.ffmpeg_lock = asyncio.Lock()
        self.user_id = user_id
        self.process = None
        self.last_encoding_update = 0
        self.formatted_name = None
        self.display_name = None
        self.metadata_code = metadata_code
        self.last_progress = ""
        self.target_channel_msg = None
        self.last_status_update = 0  # For throttling status updates

    async def get_duration(self, file_path: str) -> float:
        cmd = f"ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 '{file_path}'"
        process = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            error_msg = stderr.decode().strip()
            raise Exception(f"FFprobe error: {error_msg}")
        return float(stdout.decode().strip())

    async def update_status(self, text: str) -> None:
        """Throttled status updates to prevent spam"""
        now = time()
        # Update max every 5 seconds to reduce overhead
        if now - self.last_status_update < 5 and text != self.last_progress:
            return
            
        if self.status_message and text != self.last_progress:
            try:
                await self.status_message.edit_text(text, parse_mode=ParseMode.HTML)
                self.last_progress = text
                self.last_status_update = now
            except Exception as e:
                logger.error(f"Error updating status: {e}")

    async def update_target_channel_status(self, text: str) -> None:
        """Update status in target channel with throttling"""
        if not current_target_channel:
            return
            
        now = time()
        # Update max every 10 seconds for target channel
        if now - self.last_status_update < 10:
            return
            
        try:
            if not self.target_channel_msg:
                self.target_channel_msg = await self.__client.send_message(
                    current_target_channel,
                    text,
                    parse_mode=ParseMode.HTML
                )
            else:
                await self.target_channel_msg.edit_text(text, parse_mode=ParseMode.HTML)
            self.last_status_update = now
        except Exception as e:
            logger.error(f"Error updating target channel status: {e}")

    async def encoding_status(self, current_duration: float, total_duration: float) -> None:
        """Optimized encoding status with better throttling"""
        if self.user_id and cancel_requests.get(self.user_id, False):
            self.cancelled = True
        if self.cancelled:
            return

        now = time()
        # More aggressive throttling for 1080p
        update_interval = 10 if self.quality == '1080p' else 5
        if current_duration < total_duration and now - self.last_encoding_update < update_interval:
            return
        self.last_encoding_update = now

        percent = round((current_duration / total_duration) * 100, 2) if total_duration > 0 else 0
        elapsed = now - self.encoding_start
        speed = current_duration / elapsed if elapsed > 0 else 0
        eta = (total_duration - current_duration) / speed if speed > 0 else 0

        bar_length = 12
        filled_length = floor(percent / 100 * bar_length)
        bar = "█" * filled_length + "▒" * (bar_length - filled_length)

        status_text = f"""
<blockquote>‣ <b>Anime Name :</b> <b><i>{self.display_name}</i></b></blockquote>
<blockquote>‣ <b>Status :</b> <i>Encoding</i>
    <code>[{bar}]</code> {percent}%</blockquote> 
<blockquote>   ‣ <b>Processed :</b> {convert_time(current_duration)} / {convert_time(total_duration)}
    ‣ <b>Speed :</b> {speed:.2f}x
    ‣ <b>Time Took :</b> {convert_time(elapsed)}
    ‣ <b>Time Left :</b> {convert_time(eta)}</blockquote>
<blockquote>‣ <b>Quality :</b> <code>{self.quality.upper()}</code></blockquote>
"""
        await self.update_status(status_text)
        await self.update_target_channel_status(status_text)
        
    async def process_file(self, input_path: str, output_path: str) -> str:
        """
        OPTIMIZED file processing with fixes for 1080p stacking
        """
        import uuid, shutil, shlex, re

        self.encoding_start = time()
        self.last_encoding_update = 0
        self.last_status_update = 0

        # --- Get duration ---
        try:
            total_duration = await self.get_duration(input_path)
        except Exception as e:
            logger.error(f"Error getting duration: {e}")
            total_duration = 0

        # --- Setup paths ---
        temp_id = str(uuid.uuid4())[:8]
        temp_output = os.path.join("temp", f"temp_{temp_id}.mkv")
        final_output = output_path

        # Get appropriate FFmpeg command based on quality
        user_ffmpeg_cmd = custom_ffmpeg_commands.get(self.user_id, {}).get(self.quality)
        ffmpeg_cmd = user_ffmpeg_cmd or FFMPEG_COMMANDS.get(self.quality)
        
        if not ffmpeg_cmd:
            # Fallback to copy if no command is defined
            ffmpeg_cmd = "ffmpeg -i {input} -c:v copy -c:a copy -c:s copy -y {output}"
            if HAS_NVIDIA:
                ffmpeg_cmd = "ffmpeg -hwaccel cuda -hwaccel_output_format cuda -i {input} -c:v copy -c:a copy -c:s copy -y {output}"

        # Format the command - REMOVED progress pipe to reduce I/O
        cmd = ffmpeg_cmd.format(
            input=shlex.quote(input_path),
            output=shlex.quote(temp_output)
        )
        logger.info(f"Using processing command: {cmd}")

        if not os.path.exists(input_path):
            raise FileNotFoundError(f"Input file not found: {input_path}")

        # --- Run FFmpeg process with OPTIMIZED output handling ---
        async with self.ffmpeg_lock:
            # Use subprocess.DEVNULL for stdout to reduce I/O bottleneck
            self.process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=subprocess.DEVNULL,  # FIX: Discard stdout to reduce I/O
                stderr=asyncio.subprocess.PIPE  # Keep stderr for error reporting
            )

            # Use stderr for progress monitoring (FFmpeg's default progress output)
            time_pattern = re.compile(r"time=(\d+):(\d+):(\d+\.\d+)")
            buffer = ""
            processing_timeout = 21600  # 6 hours
            start_time = time()
            last_progress_time = 0

            while True:
                if self.cancelled:
                    self.process.terminate()
                    raise Exception("Processing cancelled by user")

                if time() - start_time > processing_timeout:
                    self.process.terminate()
                    raise TimeoutError("Processing timed out after 6 hours")

                try:
                    # FIX: Larger read size (16KB) and read from stderr
                    chunk = await asyncio.wait_for(self.process.stderr.read(16384), timeout=5.0)
                except asyncio.TimeoutError:
                    # Check if process is still running
                    if self.process.returncode is not None:
                        break
                    continue

                if not chunk:
                    # Check if process completed
                    if self.process.returncode is not None:
                        break
                    continue

                buffer += chunk.decode(errors="ignore")

                # FIX: Process buffer efficiently and clear it
                matches = list(time_pattern.findall(buffer))
                if matches:
                    # Get the latest progress time
                    h, m, s = matches[-1]
                    current_sec = int(h) * 3600 + int(m) * 60 + float(s)
                    
                    # FIX: Throttled progress updates
                    now = time()
                    if now - last_progress_time >= 5:  # Update every 5 seconds max
                        await self.encoding_status(current_sec, total_duration)
                        last_progress_time = now
                    
                    # FIX: Clear buffer after processing to prevent memory growth
                    # Find the position of the last match and keep only what's after it
                    last_match_str = f"time={h}:{m}:{s}"
                    last_pos = buffer.rfind(last_match_str)
                    if last_pos != -1:
                        buffer = buffer[last_pos + len(last_match_str):]
                else:
                    # If buffer gets too large without matches, clear it
                    if len(buffer) > 10000:  # ~10KB
                        buffer = ""

            # Wait for process completion
            await self.process.wait()
            if self.process.returncode != 0:
                stderr_output = (await self.process.stderr.read()).decode()
                logger.error(f"Base processing failed with error: {stderr_output}")
                raise Exception(f"Base processing failed: {stderr_output[:500]}")

        # --- Apply metadata if available ---
        if self.metadata_code and self.metadata_code.strip():
            metadata_cmd = METADATA_FFMPEG_COMMAND.format(
                input=shlex.quote(temp_output),
                output=shlex.quote(final_output),
                metadata=shlex.quote(self.metadata_code)
            )
            logger.info(f"Applying metadata command: {metadata_cmd}")

            async with self.ffmpeg_lock:
                self.process = await asyncio.create_subprocess_shell(
                    metadata_cmd,
                    stdout=subprocess.DEVNULL,  # FIX: Discard stdout
                    stderr=asyncio.subprocess.PIPE
                )
                await self.process.wait()
                if self.process.returncode != 0:
                    stderr_output = (await self.process.stderr.read()).decode()
                    logger.error(f"Metadata processing failed with error: {stderr_output}")
                    raise Exception(f"Metadata processing failed: {stderr_output[:500]}")

            # Cleanup temp file
            try:
                os.remove(temp_output)
            except Exception as e:
                logger.warning(f"Could not remove temp file {temp_output}: {e}")

        else:
            # No metadata → just move/copy file
            try:
                os.rename(temp_output, final_output)
            except Exception:
                logger.warning(f"Could not rename temp file, copying instead")
                try:
                    shutil.copy2(temp_output, final_output)
                finally:
                    try:
                        os.remove(temp_output)
                    except Exception as e:
                        logger.warning(f"Could not remove temp file {temp_output}: {e}")

        return final_output    
    
    async def progress_status(self, current: int, total: int) -> None:
        if self.user_id and cancel_requests.get(self.user_id, False):
            self.cancelled = True
        if self.cancelled:
            self.__client.stop_transmission()

        now = time()
        diff = now - self.__start
        if current < total and now - self.__updater < 10:
            return
        self.__updater = now

        percent = round(current / total * 100, 2) if total > 0 else 0
        speed = current / diff if diff > 0 else 0
        eta = round((total - current) / speed) if speed > 0 and current < total else 0

        bar_length = 12
        filled_length = floor(percent / 100 * bar_length)
        bar = "█" * filled_length + "▒" * (bar_length - filled_length)

        status_text = f"""
<blockquote>‣ <b>Anime Name :</b> <b><i>{self.display_name}</i></b></blockquote>
<blockquote>‣ <b>Status :</b> <i>Uploading</i>
    <code>[{bar}]</code> {percent}%</blockquote> 
<blockquote>   ‣ <b>Size :</b> {convert_bytes(current)} / {convert_bytes(total)}
    ‣ <b>Speed :</b> {convert_bytes(speed)}/s
    ‣ <b>Time Took :</b> {convert_time(diff)}
    ‣ <b>Time Left :</b> {convert_time(eta)}</blockquote>
<blockquote>‣ <b>Quality :</b> <code>{self.quality.upper()}</code></blockquote>
"""
        await self.update_status(status_text)
        await self.update_target_channel_status(status_text)

    async def process_and_upload(self) -> Tuple[int, int]:
        self.__start = time()
        self.__updater = self.__start
        upload_path = self.file_path

        try:
            editor = TextEditor(self.__name)
            await editor.load_anilist()
            self.display_name = await editor.get_formatted_name(self.quality, include_brand=False)
            self.formatted_name = await editor.get_formatted_name(self.quality, include_brand=True)

            await self.update_status(
                f"<blockquote><b>⏳ Starting processing for {self.quality.upper()}...</b></blockquote>\n"
                f"<blockquote>File: {self.display_name}</blockquote>"
            )

            output_path = os.path.join("temp", self.formatted_name)
            await self.update_status(
                f"<blockquote><b>🔧 Processing {self.quality.upper()} file...</b></blockquote>\n"
                f"<blockquote>File: {self.display_name}</blockquote>"
            )
            await self.update_target_channel_status(
                f"<blockquote><b>⏳ Starting processing for {self.quality.upper()}...</b></blockquote>\n"
                f"<blockquote>File: {self.display_name}</blockquote>"
            )

            try:
                upload_path = await self.process_file(self.file_path, output_path)
            except Exception as e:
                logger.error(f"Processing failed: {e}")
                await self.update_status(
                    f"<blockquote><b>❌ Processing failed for {self.quality.upper()}</b></blockquote>\n"
                    f"<blockquote>Error: {str(e)[:100]}</blockquote>"
                )
                await self.update_target_channel_status(
                    f"<blockquote><b>❌ Processing failed for {self.quality.upper()}</b></blockquote>\n"
                    f"<blockquote>Error: {str(e)[:100]}</blockquote>"
                )
                raise

            await self.update_status(
                f"<blockquote><b>📤 Uploading {self.quality.upper()}...</b></blockquote>\n"
                f"<blockquote>File: {self.display_name}</blockquote>"
            )
            await self.update_target_channel_status(
                f"<blockquote><b>📤 Uploading {self.quality.upper()}...</b></blockquote>\n"
                f"<blockquote>File: {self.display_name}</blockquote>"
            )

            thumb_path = None
            if self.user_id in user_thumbnails and os.path.exists(user_thumbnails[self.user_id]):
                thumb_path = user_thumbnails[self.user_id]
            elif os.path.exists(THUMBNAIL_PATH):
                thumb_path = THUMBNAIL_PATH

            msg = await self.__client.send_document(
                chat_id=FILE_STORE,
                document=upload_path,
                thumb=thumb_path,
                caption=f"<blockquote><b>{self.formatted_name}</b></blockquote>",
                file_name=self.formatted_name,
                progress=self.progress_status
            )
            file_size = msg.document.file_size
            return msg.id, file_size

        except FloodWait as e:
            await asyncio.sleep(e.value * 1.5)
            return await self.process_and_upload()
        except Exception as e:
            logger.error(f"Error in process_and_upload: {traceback.format_exc()}")
            try:
                await self.message.reply_text(f"❌ Error during processing: {str(e)[:300]}")
            except:
                pass
            raise
        finally:
            try:
                if upload_path != self.file_path and os.path.exists(upload_path):
                    os.remove(upload_path)
            except Exception as e:
                logger.error(f"Error removing file: {e}")
            if self.status_message:
                asyncio.create_task(safe_delete_message(self.status_message))
            if self.target_channel_msg:
                asyncio.create_task(safe_delete_message(self.target_channel_msg))

# Process Queue Manager
async def process_queue_manager():
    global active_encodings
    while True:
        async with processing_lock:
            if encoding_queue.empty():
                await asyncio.sleep(5)
                continue
                
            task = await encoding_queue.get()
            try:
                active_encodings += 1
                await process_task(task)
            except Exception as e:
                logger.error(f"Error processing task: {traceback.format_exc()}")
                try:
                    await task["callback_query"].message.reply_text(f"❌ Error processing task: {str(e)[:300]}")
                except:
                    pass
            finally:
                encoding_queue.task_done()
                active_encodings -= 1
                await asyncio.sleep(2)  # Increased delay between tasks

async def reset_user_session(user_id: int):
    """Safely reset user session without affecting multi-mode setting"""
    user_sessions[user_id] = {
        "state": "waiting_photo",
        "cover_photo": None,
        "videos": {"480p": None, "720p": None, "1080p": None},
        "target_channel": TARGET_CHANNEL,
        "language": "Tamil",
        "codec": "HEVC",
        "anilist_data": None
    }
    
    # Only clear source file, keep multi-mode setting
    if user_id in multi_mode_settings:
        multi_mode_settings[user_id]["source_file"] = None

async def process_task(task: dict):
    session = task["session"]
    callback_query = task["callback_query"]
    user_id = task["user_id"]
    source_file = task.get("source_file")  # Get source file from task data
    
    try:
        # Use current target channel or session target channel
        target_channel = current_target_channel or session.get("target_channel")
        
        if not target_channel:
            await callback_query.message.reply_text("❌ No target channel set. Use /post to set a channel first.")
            return
            
        # Check if we're in multi mode - FIXED: Use task data instead of global settings
        is_multi_mode = task.get("is_multi_mode", False)
        
        logger.info(f"Processing task - Multi mode: {is_multi_mode}, Source file: {source_file is not None}")
        
        # FIX: Don't reset session here - wait until processing is complete
        if is_multi_mode and source_file:
            # Multi mode processing - one source file, multiple outputs
            await process_multi_mode(task, source_file, target_channel)
        else:
            # Normal mode processing - separate files for each quality
            await process_normal_mode(task, target_channel)
            
    except Exception as e:
        logger.error(f"Error during publishing: {traceback.format_exc()}")
        try:
            await app.send_message(user_id, f"❌ Error publishing content: {str(e)[:300]}")
        except:
            pass
    finally:
        if user_id in cancel_requests:
            cancel_requests[user_id] = False

async def process_normal_mode(task: dict, target_channel: int):
    session = task["session"]
    callback_query = task["callback_query"]
    user_id = task["user_id"]
    
    # FIX: Check if we have any videos in the session
    videos = [v for v in session["videos"].values() if v]
    if not videos:
        await callback_query.message.reply_text("❌ No video files found in session. Please start over.")
        await reset_user_session(user_id)
        return
    
    video_msg = videos[0]  # Get first available video
    filename = video_msg.video.file_name if video_msg.video else video_msg.document.file_name
    
    # Get formatted name for display (without brand)
    editor = TextEditor(filename)
    editor.adata = session["anilist_data"]
    formatted_name = await editor.get_formatted_name('480p', include_brand=False)
    
    if len(formatted_name) > 50:
        display_name = formatted_name[:47] + "..."
    else:
        display_name = formatted_name
    
    # Use new caption format
    caption = await editor.get_caption(
        session['language'], 
        session['codec'], 
        "480p, 720p, 1080p"
    ) or f"<blockquote><b>➤ {await editor.get_title()}</b></blockquote>\n" + \
        "<b>────────────────</b>\n" + \
        f"<b>‣ Language :</b> {session['language']}\n" + \
        f"<b>‣ Codec :</b> {session['codec']}\n" + \
        f"<b>‣ Quality :</b> 480p, 720p, 1080p\n" + \
        "<b>────────────────</b>"
    
    # Send to target channel without buttons initially
    try:
        main_post_msg = await app.send_photo(
            chat_id=target_channel,
            photo=session["cover_photo"],
            caption=caption,
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Error sending to target channel: {e}")
        await app.send_message(user_id, f"❌ Error posting to target channel: {e}")
        await reset_user_session(user_id)
        return
    
    # Get target channel invite link
    target_invite_link = await create_persistent_invite_link(target_channel)
    
    # Create update channel buttons with invite link
    update_buttons = [
        [InlineKeyboardButton("🎬 Watch Now", url=target_invite_link)]
    ]
    
    # Send to update channel with buttons (if enabled)
    update_post_msg = None
    if UPDATE_CHANNEL_ENABLED:
        try:
            update_post_msg = await app.send_photo(
                chat_id=UPDATE_CHANNEL,
                photo=session["cover_photo"],
                caption=caption,
                reply_markup=InlineKeyboardMarkup(update_buttons),
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Error sending to update channel: {e}")
    
    # Send status message to owner
    owner_status_msg = await app.send_message(
        OWNER_ID,
        f"<blockquote><b>⏳ Processing videos sequentially, please wait...</b></blockquote>\n"
        f"<blockquote>File: {display_name}</blockquote>\n"
        f"<blockquote>Target Channel: {target_channel}</blockquote>",
        parse_mode=ParseMode.HTML
    )
    
    # Initialize quality buttons list
    quality_buttons = []
    
    errors = []
    file_paths = []
    
    cancel_requests[user_id] = False
    
    # Process qualities in order
    for quality in ['480p', '720p', '1080p']:
        if cancel_requests.get(user_id, False):
            errors.append("Operation cancelled by user")
            break
            
        video_msg = session["videos"].get(quality)
        if video_msg:
            logger.info(f"Starting processing for {quality}")
            # Get metadata setting for this user
            metadata_code = None
            if user_id in metadata_settings and metadata_settings[user_id].get("enabled"):
                metadata_code = metadata_settings[user_id].get("code")
            
            result = await process_quality(
                session, quality, video_msg, filename, 
                owner_status_msg, main_post_msg, quality_buttons, 
                metadata_code, user_id
            )
            if isinstance(result, tuple):
                quality_res, res = result
                if isinstance(res, str):
                    errors.append(f"{quality}: {res}")
                else:
                    file_paths.append(res)
        else:
            logger.warning(f"No video provided for {quality}")
    
    if errors:
        error_message = "❌ Errors occurred:\n" + "\n".join(errors)
        try:
            await owner_status_msg.edit_text(error_message)
        except:
            pass
        await app.send_message(user_id, "❌ Errors occurred during publishing")
        for file_path in file_paths:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except:
                pass
        await reset_user_session(user_id)
        return
    
    # Update target channel post with quality buttons
    try:
        await main_post_msg.edit_reply_markup(
            InlineKeyboardMarkup(quality_buttons)
        )
    except Exception as e:
        logger.error(f"Error updating target channel buttons: {e}")
    
    # Clean up files
    for file_path in file_paths:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except:
            pass
    
    # Update status messages
    await safe_edit_message(owner_status_msg,
        f"""<blockquote><b>✅ All processing completed!</b></blockquote>
<blockquote>File: {display_name}</blockquote>
<blockquote>Target Channel: {target_channel}</blockquote>""",
        ParseMode.HTML
    )
    asyncio.create_task(safe_delete_message(owner_status_msg, 10))
    
    # Send success message
    success_message = (
        f"✅ Content published to target channel!\n\n"
        f"• Target Channel: {target_channel}\n"
    )
    if UPDATE_CHANNEL_ENABLED:
        success_message += f"• Update Channel: {UPDATE_CHANNEL}"
    
    await app.send_message(user_id, success_message)
    
    # Reset session after successful completion
    await reset_user_session(user_id)

async def process_multi_mode(task: dict, source_file: Message, target_channel: int):
    session = task["session"]
    callback_query = task["callback_query"]
    user_id = task["user_id"]
    
    filename = source_file.video.file_name if source_file.video else source_file.document.file_name
    
    # Get formatted name for display (without brand)
    editor = TextEditor(filename)
    editor.adata = session["anilist_data"]
    formatted_name = await editor.get_formatted_name('480p', include_brand=False)
    
    if len(formatted_name) > 50:
        display_name = formatted_name[:47] + "..."
    else:
        display_name = formatted_name
    
    # Use new caption format
    caption = await editor.get_caption(
        session['language'], 
        session['codec'], 
        "480p, 720p, 1080p"
    ) or f"<blockquote><b>➤ {await editor.get_title()}</b></blockquote>\n" + \
        "<b>────────────────</b>\n" + \
        f"<b>‣ Language :</b> {session['language']}\n" + \
        f"<b>‣ Codec :</b> {session['codec']}\n" + \
        f"<b>‣ Quality :</b> 480p, 720p, 1080p\n" + \
        "<b>────────────────</b>"
    
    # Send to target channel without buttons initially
    try:
        main_post_msg = await app.send_photo(
            chat_id=target_channel,
            photo=session["cover_photo"],
            caption=caption,
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Error sending to target channel: {e}")
        await app.send_message(user_id, f"❌ Error posting to target channel: {e}")
        await reset_user_session(user_id)
        return
    
    # Get target channel invite link
    target_invite_link = await create_persistent_invite_link(target_channel)
    
    # Create update channel buttons with invite link
    update_buttons = [
        [InlineKeyboardButton("🎬 Watch Now", url=target_invite_link)]
    ]
    
    # Send to update channel with buttons (if enabled)
    update_post_msg = None
    if UPDATE_CHANNEL_ENABLED:
        try:
            update_post_msg = await app.send_photo(
                chat_id=UPDATE_CHANNEL,
                photo=session["cover_photo"],
                caption=caption,
                reply_markup=InlineKeyboardMarkup(update_buttons),
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Error sending to update channel: {e}")
    
    # Send status message to owner
    owner_status_msg = await app.send_message(
        OWNER_ID,
        f"<blockquote><b>⏳ Multi-mode processing started...</b></blockquote>\n"
        f"<blockquote>File: {display_name}</blockquote>\n"
        f"<blockquote>Target Channel: {target_channel}</blockquote>",
        parse_mode=ParseMode.HTML
    )
    
    # Initialize quality buttons list
    quality_buttons = []
    
    errors = []
    file_paths = []
    
    cancel_requests[user_id] = False
    
    # Download the source file once
    source_file_path = await download_telegram_file(
        source_file, 
        "source",
        filename,
        session["anilist_data"],
        owner_status_msg
    )
    
    if not source_file_path:
        errors.append("Source file download failed")
        await owner_status_msg.edit_text("❌ Source file download failed")
        await reset_user_session(user_id)
        return
    
    # Process qualities in order
    for quality in ['480p', '720p', '1080p']:
        if cancel_requests.get(user_id, False):
            errors.append("Operation cancelled by user")
            break
            
        logger.info(f"Starting multi-mode processing for {quality}")
        # Get metadata setting for this user
        metadata_code = None
        if user_id in metadata_settings and metadata_settings[user_id].get("enabled"):
            metadata_code = metadata_settings[user_id].get("code")
        
        result = await process_multi_quality(
            session, quality, source_file_path, filename, 
            owner_status_msg, main_post_msg, quality_buttons, 
            metadata_code, user_id
        )
        if isinstance(result, tuple):
            quality_res, res = result
            if isinstance(res, str):
                errors.append(f"{quality}: {res}")
            else:
                file_paths.append(res)
    
    # Clean up source file
    try:
        if os.path.exists(source_file_path):
            os.remove(source_file_path)
    except:
        pass
    
    if errors:
        error_message = "❌ Errors occurred:\n" + "\n".join(errors)
        try:
            await owner_status_msg.edit_text(error_message)
        except:
            pass
        await app.send_message(user_id, "❌ Errors occurred during publishing")
        for file_path in file_paths:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except:
                pass
        await reset_user_session(user_id)
        return
    
    # Update target channel post with quality buttons
    try:
        await main_post_msg.edit_reply_markup(
            InlineKeyboardMarkup(quality_buttons)
        )
    except Exception as e:
        logger.error(f"Error updating target channel buttons: {e}")
    
    # Clean up files
    for file_path in file_paths:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except:
            pass
    
    # Update status messages
    await safe_edit_message(owner_status_msg,
        f"""<blockquote><b>✅ Multi-mode processing completed!</b></blockquote>
<blockquote>File: {display_name}</blockquote>
<blockquote>Target Channel: {target_channel}</blockquote>""",
        ParseMode.HTML
    )
    asyncio.create_task(safe_delete_message(owner_status_msg, 10))
    
    # Send success message
    success_message = (
        f"✅ Multi-mode content published to target channel!\n\n"
        f"• Target Channel: {target_channel}\n"
    )
    if UPDATE_CHANNEL_ENABLED:
        success_message += f"• Update Channel: {UPDATE_CHANNEL}"
    
    await app.send_message(user_id, success_message)
    
    # Reset session after successful completion
    await reset_user_session(user_id)

async def process_multi_quality(session: dict, quality: str, source_file_path: str, filename: str, 
                               owner_status_msg: Message, main_post_msg: Message, buttons: list, 
                               metadata_code: Optional[str], user_id: int) -> Tuple[str, str]:
    try:
        # Get formatted name for display (without brand)
        editor = TextEditor(filename)
        editor.adata = session["anilist_data"]
        formatted_name = await editor.get_formatted_name(quality, include_brand=False)
        
        if len(formatted_name) > 50:
            display_name = formatted_name[:47] + "..."
        else:
            display_name = formatted_name
            
        # Update status messages to owner
        owner_quality_status = await app.send_message(
            OWNER_ID,
            f"<blockquote><b>⏳ Multi-mode processing {quality} started...</b></blockquote>\n"
            f"<blockquote>File: {display_name}</blockquote>",
            parse_mode=ParseMode.HTML
        )
        
        if cancel_requests.get(user_id, False):
            return quality, "Cancelled before start"
        
        processor = FileProcessor(
            client=app,
            message=None,
            rep=None,
            file_path=source_file_path,
            quality=quality,
            status_message=owner_quality_status,
            user_id=user_id,
            metadata_code=metadata_code
        )
        
        msg_id, file_size = await processor.process_and_upload()
        
        if processor.cancelled:
            try:
                await app.delete_messages(FILE_STORE, [msg_id])
            except:
                pass
            return quality, "Cancelled during processing"
        
        link = await create_download_link(msg_id)
        btn_text = f"{btn_formatter.get(quality, quality)} - {convert_bytes(file_size)}"
        
        # Update button adding logic
        if quality == '480p':
            buttons.append([InlineKeyboardButton(btn_text, url=link)])
        elif quality == '720p':
            if buttons and len(buttons[-1]) == 1:
                buttons[-1].append(InlineKeyboardButton(btn_text, url=link))
            else:
                buttons.append([InlineKeyboardButton(btn_text, url=link)])
        elif quality == '1080p':
            buttons.append([InlineKeyboardButton(btn_text, url=link)])
        
        try:
            if buttons:
                await main_post_msg.edit_reply_markup(
                    InlineKeyboardMarkup(buttons)
                )
        except Exception as e:
            logger.error(f"Error updating buttons: {e}")
        
        await safe_edit_message(owner_quality_status,
            f"""<blockquote><b>✅ Multi-mode processing completed for {quality}!</b></blockquote>
<blockquote>File: {display_name}</blockquote>""",
            ParseMode.HTML
        )
        
        asyncio.create_task(safe_delete_message(owner_quality_status))
        
        return quality, source_file_path
    except FloodWait as e:
        await asyncio.sleep(e.value)
        return quality, "FloodWait error"
    except Exception as e:
        logger.error(f"Error processing {quality} video: {traceback.format_exc()}")
        return quality, f"{str(e)[:100]}"

async def process_quality(session: dict, quality: str, video_msg: Message, filename: str, 
                         owner_status_msg: Message, main_post_msg: Message, buttons: list, 
                         metadata_code: Optional[str], user_id: int) -> Tuple[str, str]:
    try:
        # Get formatted name for display (without brand)
        editor = TextEditor(filename)
        editor.adata = session["anilist_data"]
        formatted_name = await editor.get_formatted_name(quality, include_brand=False)
        
        if len(formatted_name) > 50:
            display_name = formatted_name[:47] + "..."
        else:
            display_name = formatted_name
            
        # Update status messages to owner
        owner_quality_status = await app.send_message(
            OWNER_ID,
            f"<blockquote><b>⏳ Processing {quality} started...</b></blockquote>\n"
            f"<blockquote>File: {display_name}</blockquote>",
            parse_mode=ParseMode.HTML
        )
        
        if cancel_requests.get(user_id, False):
            return quality, "Cancelled before start"
        
        file_path = await download_telegram_file(
            video_msg, 
            quality,
            filename,
            session["anilist_data"],
            owner_quality_status
        )
        if not file_path:
            return quality, "Download failed"
        
        if cancel_requests.get(user_id, False):
            if os.path.exists(file_path):
                os.remove(file_path)
            return quality, "Cancelled after download"
        
        processor = FileProcessor(
            client=app,
            message=video_msg,
            rep=None,
            file_path=file_path,
            quality=quality,
            status_message=owner_quality_status,
            user_id=user_id,
            metadata_code=metadata_code
        )
        
        msg_id, file_size = await processor.process_and_upload()
        
        if processor.cancelled:
            try:
                await app.delete_messages(FILE_STORE, [msg_id])
            except:
                pass
            return quality, "Cancelled during processing"
        
        link = await create_download_link(msg_id)
        btn_text = f"{btn_formatter.get(quality, quality)} - {convert_bytes(file_size)}"
        
        # Update button adding logic
        if quality == '480p':
            buttons.append([InlineKeyboardButton(btn_text, url=link)])
        elif quality == '720p':
            if buttons and len(buttons[-1]) == 1:
                buttons[-1].append(InlineKeyboardButton(btn_text, url=link))
            else:
                buttons.append([InlineKeyboardButton(btn_text, url=link)])
        elif quality == '1080p':
            buttons.append([InlineKeyboardButton(btn_text, url=link)])
        
        try:
            if buttons:
                await main_post_msg.edit_reply_markup(
                    InlineKeyboardMarkup(buttons)
                )
        except Exception as e:
            logger.error(f"Error updating buttons: {e}")
        
        await safe_edit_message(owner_quality_status,
            f"""<blockquote><b>✅ Processing completed for {quality}!</b></blockquote>
<blockquote>File: {display_name}</blockquote>""",
            ParseMode.HTML
        )
        
        asyncio.create_task(safe_delete_message(owner_quality_status))
        
        return quality, file_path
    except FloodWait as e:
        await asyncio.sleep(e.value)
        return quality, "FloodWait error"
    except Exception as e:
        logger.error(f"Error processing {quality} video: {traceback.format_exc()}")
        return quality, f"{str(e)[:100]}"

async def download_telegram_file(message: Message, quality: str, filename: str, 
                                anilist_data: dict, status_msg: Message) -> Optional[str]:
    try:
        os.makedirs("temp", exist_ok=True)
        
        if message.video:
            file_id = message.video.file_id
            total_size = message.video.file_size
        elif message.document:
            file_id = message.document.file_id
            total_size = message.document.file_size
        else:
            return None
        
        # Get formatted name from AniList (without brand)
        editor = TextEditor(filename)
        editor.adata = anilist_data
        formatted_name = await editor.get_formatted_name(quality, include_brand=False)
        
        # Create display name
        if len(formatted_name) > 50:
            display_name = formatted_name[:47] + "..."
        else:
            display_name = formatted_name
        
        # Create safe file path
        file_path = os.path.join("temp", formatted_name)
        
        await safe_edit_message(status_msg,
            f"""<blockquote><b>📥 Downloading {quality} file...</b></blockquote>
<blockquote>File: {display_name}</blockquote>""",
            ParseMode.HTML
        )
        
        start_time = time()
        last_update = start_time
        last_current = 0
        actual_total = total_size
        
        async def progress_callback(current, total):
            nonlocal last_update, last_current, actual_total
            now = time()
            
            if total > 0:
                actual_total = total
            
            if now - last_update < 10 and current != actual_total:
                return
                
            last_update = now
            elapsed = now - start_time
            chunk_size = current - last_current
            last_current = current
            
            if elapsed > 0:
                speed = current / elapsed
            else:
                speed = 0
                
            if actual_total > 0 and speed > 0:
                eta = (actual_total - current) / speed
            else:
                eta = 0
            
            if actual_total > 0:
                percent = round(current / actual_total * 100, 2)
                bar_length = 12
                filled_length = int(bar_length * percent // 100)
                bar = "█" * filled_length + "▒" * (bar_length - filled_length)
            else:
                percent = 0.0
                bar = "▒" * 12
            
            status_text = f"""
<blockquote>‣ <b>Anime Name :</b> <b><i>{display_name}</i></b></blockquote>
<blockquote>‣ <b>Status :</b> <i>Downloading</i>
    <code>[{bar}]</code> {percent}%</blockquote> 
<blockquote>   ‣ <b>Size :</b> {convert_bytes(current)} / {convert_bytes(actual_total) if actual_total > 0 else 'Unknown'}
    ‣ <b>Speed :</b> {convert_bytes(speed)}/s
    ‣ <b>Time Took :</b> {convert_time(elapsed)}
    ‣ <b>Time Left :</b> {convert_time(eta) if eta > 0 else 'Calculating...'}</blockquote>
<blockquote>‣ <b>Quality :</b> <code>{quality}</code></blockquote>
"""
            
            try:
                await safe_edit_message(status_msg, status_text, ParseMode.HTML)
            except Exception as e:
                logger.error(f"Error updating download status: {e}")
        
        await app.download_media(
            message=file_id,
            file_name=file_path,
            progress=progress_callback
        )
        
        await progress_callback(actual_total, actual_total)
        
        downloaded_size = os.path.getsize(file_path)
        if actual_total > 0 and downloaded_size != actual_total:
            logger.warning(f"Size mismatch: Expected {actual_total}, got {downloaded_size}")
            raise Exception(f"Download incomplete: {convert_bytes(downloaded_size)}/{convert_bytes(actual_total)}")
        
        logger.info(f"Downloaded {formatted_name} ({convert_bytes(downloaded_size)}) in {time() - start_time:.2f}s")
        try:
            if status_msg:
                await status_msg.delete()
        except Exception as e:
            logger.warning(f"Failed to delete download status messages: {e}")

        return file_path
    except Exception as e:
        logger.error(f"Error downloading file: {traceback.format_exc()}")
        return None

# Bot Command Handlers
@app.on_message(filters.command("start") & filters.private)
async def handle_start_command(client: Client, message: Message):
    args = message.text.split()
    user_id = message.from_user.id
    first_name = html.escape(message.from_user.first_name) if message.from_user.first_name else "User"
    
    # Start message caption
    greeting = f"<blockquote><b>Hey {first_name},</b></blockquote>\n"
    bot_description = "<blockquote><b>𝗂 𝖺𝗆 𝖺 𝖺𝖽𝗏𝖺𝗇𝖼𝖾𝖽 𝗍𝖾𝗅𝖾𝗀𝗋𝖺𝗆 𝖻𝗈𝗍 𝗍𝗁𝖺𝗍 𝖺𝗅𝗅𝗈𝗐𝗌 𝗒𝗈𝗎 𝗍𝗈 𝖽𝗈𝗐𝗇𝗅𝗈𝖺𝖽 𝗒𝗈𝗎𝗋 𝖿𝖺𝗏𝗈𝗋𝗂𝗍𝖾 𝗌𝖾𝗋𝗂𝖾𝗌 𝖺𝗇𝖽 𝖾𝗉𝗂𝗌𝗈𝖽𝖾𝗌 𝖽𝗂𝗋𝖾𝖼𝗍𝗅𝗒</b></blockquote>"
    caption = greeting + bot_description
    
    # Create buttons for the start message
    buttons = [
        [
            InlineKeyboardButton("🔰 Main Channel", url="https://t.me/ATXanime"),
            InlineKeyboardButton("📇 About", callback_data="about_bot")
        ],
        [
            InlineKeyboardButton("👑 Developer", user_id=OWNER_ID)
        ]
    ]
    
    if len(args) > 1:
        try:
            encoded_str = args[1]
            decoded_str = decode(encoded_str)
            
            if decoded_str.startswith("get-"):
                multiplied_id = int(decoded_str.split('-')[1])
                msg_id = multiplied_id // abs(FILE_STORE)
                
                is_subscribed = await check_user_subscription(user_id)
                
                if not is_subscribed:
                    temp_force_sub_data[user_id] = {
                        "msg_id": msg_id,
                        "original_message_id": message.id
                    }
                    
                    # Force subscription text
                    force_sub_text = (
                        "<blockquote><b>⚠️ You must join our channels to use this bot!</b></blockquote>\n\n"
                        "<blockquote><b>Please join the following channel(s) and click Verify Subscription:</b></blockquote>\n\n"
                    )
                    
                    caption = greeting + bot_description + force_sub_text
                    
                    force_sub_buttons = []
                    for channel_id in force_sub_channels:
                        try:
                            chat = await client.get_chat(channel_id)
                            invite_link = await create_persistent_invite_link(channel_id)
                            force_sub_buttons.append([InlineKeyboardButton(f"Join {chat.title}", url=invite_link)])
                        except Exception as e:
                            logger.error(f"Error getting chat for {channel_id}: {e}")
                    
                    force_sub_buttons.append([InlineKeyboardButton("✅ Verify Subscription", callback_data=f"verify_{user_id}")])
                    
                    await message.reply_photo(
                        photo=START_IMAGE_URL,
                        caption=caption,
                        reply_markup=InlineKeyboardMarkup(force_sub_buttons),
                        parse_mode=ParseMode.HTML
                    )
                    return
                
                try:
                    msg = await client.get_messages(FILE_STORE, message_ids=msg_id)
                    if msg:
                        file_caption = f"<blockquote><b>{msg.caption}</b></blockquote>"
                        file_msg = await msg.copy(
                            message.chat.id, 
                            caption=file_caption,
                            parse_mode=ParseMode.HTML
                        )
                        
                        warning_text = (
                            "<blockquote><b>Tʜɪs Fɪʟᴇ ᴡɪʟʟ ʙᴇ Dᴇʟᴇᴛᴇᴅ ɪɴ 30 mins.</b> "
                            "<b>Pʟᴇᴀsᴇ sᴀᴠᴇ ᴏʀ ғᴏʀᴡᴀʀᴅ ɪᴛ ᴛᴏ ʏᴏᴜʀ sᴀᴠᴇᴅ ᴍᴇssᴀɢᴇs "
                            "ʙᴇғᴏʀᴇ ɪᴛ ɢᴇᴛs Dᴇʟᴇᴛᴇᴅ.</blockquote>"
                        )
                        warning_msg = await message.reply_text(
                            warning_text,
                            parse_mode=ParseMode.HTML,
                            reply_to_message_id=file_msg.id
                        )
                        
                        message_ids = [file_msg.id, warning_msg.id]
                        asyncio.create_task(
                            delete_messages_after_delay(message.chat.id, message_ids, DELETE_DELAY)
                        )
                        
                        file_messages_to_delete[file_msg.id] = {
                            "chat_id": message.chat.id,
                            "delete_time": asyncio.get_event_loop().time() + DELETE_DELAY
                        }
                        return
                    else:
                        await message.reply_text("❌ File not found. It may have been deleted.")
                except Exception as e:
                    logger.error(f"Error retrieving file: {e}")
                    await message.reply_text("❌ Error retrieving file. Please try again later.")
                return
        except Exception as e:
            logger.error(f"Error processing start command: {e}")
    
    # If no arguments or not file request, send the start message
    await message.reply_photo(
        photo=START_IMAGE_URL,
        caption=caption,
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode=ParseMode.HTML
    )

@app.on_message(filters.command("settings") & filters.private)
async def show_settings_menu(client: Client, message: Message):
    user_id = message.from_user.id
    if user_id != OWNER_ID:
        await message.reply_text("🚫 Only the owner can access settings.")
        return
    
    bool_metadata = metadata_settings.get(user_id, {}).get("enabled", False)
    user_metadata = metadata_settings.get(user_id, {}).get("code", "")
    multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
    
    settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""
    
    buttons = [
        [
            InlineKeyboardButton(
                'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                callback_data=f'metadata_{"1" if bool_metadata else "0"}'
            )
        ],
        [
            InlineKeyboardButton(
                'Queue: ON' if queue_enabled else 'Queue: OFF',
                callback_data=f'toggle_queue'
            )
        ],
        [
            InlineKeyboardButton(
                'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                callback_data=f'toggle_multi_mode'
            )
        ],
        [
            InlineKeyboardButton(
                'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                callback_data=f'toggle_update_channel'
            )
        ],
        [
            InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
        ],
        [
            InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_start")]
    ]
    
    await message.reply_photo(
        photo=START_IMAGE_URL,
        caption=settings_text,
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode=ParseMode.HTML
    )

@app.on_message(filters.command("mood") & filters.private & filters.user(OWNER_ID))
async def toggle_multi_mode(client: Client, message: Message):
    user_id = message.from_user.id
    
    if user_id not in multi_mode_settings:
        multi_mode_settings[user_id] = {"enabled": False, "source_file": None}
    
    # Toggle multi mode
    multi_mode_settings[user_id]["enabled"] = not multi_mode_settings[user_id]["enabled"]
    
    mode_status = "enabled" if multi_mode_settings[user_id]["enabled"] else "disabled"
    await message.reply_text(f"✅ Multi mode {mode_status}!")
    
    if multi_mode_settings[user_id]["enabled"]:
        await message.reply_text(
            "📝 Multi mode is now enabled. You only need to send one high-quality video file, "
            "and the bot will automatically encode it to 480p, 720p, and 1080p."
        )
    else:
        await message.reply_text(
            "📝 Normal mode is now enabled. You need to send 3 separate video files (480p, 720p, 1080p)."
        )

@app.on_message(filters.command("set1") & filters.private & filters.user(OWNER_ID))
async def set_ffmpeg_command_480p(client: Client, message: Message):
    await set_ffmpeg_command(client, message, "480p")

@app.on_message(filters.command("set2") & filters.private & filters.user(OWNER_ID))
async def set_ffmpeg_command_720p(client: Client, message: Message):
    await set_ffmpeg_command(client, message, "720p")

@app.on_message(filters.command("set3") & filters.private & filters.user(OWNER_ID))
async def set_ffmpeg_command_1080p(client: Client, message: Message):
    await set_ffmpeg_command(client, message, "1080p")

async def set_ffmpeg_command(client: Client, message: Message, quality: str):
    if len(message.command) < 2:
        await message.reply_text(
            f"Usage: /set{quality[-3]} <command>\n"
            "Example: /set1 ffmpeg -i {input} -c:v hevc_nvenc -preset p7 -b:v 800k -maxrate 1000k -bufsize 2000k -vf scale=854:480 -c:a copy {output}\n\n"
            "💡 Note: Use {input} and {output} as placeholders\n"
            "The command should include all necessary parameters for encoding"
        )
        return
    
    cmd = message.text.split(" ", 1)[1]
    user_id = message.from_user.id
    
    if user_id not in custom_ffmpeg_commands:
        custom_ffmpeg_commands[user_id] = {}
    
    custom_ffmpeg_commands[user_id][quality] = cmd
    await message.reply_text(f"✅ {quality} FFmpeg command set to:\n<code>{cmd}</code>")

@app.on_message(filters.command("thumb") & filters.private)
async def set_thumbnail(client: Client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        await message.reply_text("❌ Please reply to a photo to set as thumbnail.")
        return

    try:
        user_id = message.from_user.id
        # Download the photo
        thumb_path = f"thumb_{user_id}.jpg"
        photo_path = await app.download_media(
            message.reply_to_message.photo.file_id, 
            file_name=thumb_path
        )
        
        # Verify the file was downloaded successfully
        if not os.path.exists(photo_path):
            await message.reply_text("❌ Failed to download the thumbnail.")
            return
            
        # Process the image
        img = Image.open(photo_path).convert("RGB")
        img = img.resize((320, 320))
        img.save(photo_path, "JPEG")
        
        # Store the thumbnail path
        user_thumbnails[user_id] = photo_path
        await message.reply_text("✅ Thumbnail set successfully!")
    except Exception as e:
        logger.error(f"Error setting thumbnail: {e}")
        await message.reply_text(f"❌ Error setting thumbnail: {e}")

@app.on_message(filters.command("viewthumb") & filters.private)
async def view_thumbnail(client: Client, message: Message):
    user_id = message.from_user.id
    if user_id in user_thumbnails and os.path.exists(user_thumbnails[user_id]):
        await client.send_photo(message.chat.id, photo=user_thumbnails[user_id])
    else:
        await message.reply_text("You don't have any thumbnail set ❌")

@app.on_message(filters.command("delthumb") & filters.private)
async def remove_thumbnail(client: Client, message: Message):
    user_id = message.from_user.id
    if user_id in user_thumbnails:
        try:
            os.remove(user_thumbnails[user_id])
        except:
            pass
        del user_thumbnails[user_id]
        await message.reply_text("Thumbnail deleted successfully 🗑️")
    else:
        await message.reply_text("You don't have any thumbnail to delete")
        
@app.on_message(filters.command("cancel") & filters.private & filters.user(OWNER_ID))
async def cancel_operation(client: Client, message: Message):
    user_id = message.from_user.id
    if user_id in user_sessions:
        # Clear the session
        del user_sessions[user_id]
    
    # Set cancel flag
    cancel_requests[user_id] = True
    
    # Clean up temp files
    try:
        for file in os.listdir("temp"):
            file_path = os.path.join("temp", file)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)
            except Exception as e:
                logger.error(f"Error deleting file {file_path}: {e}")
    except Exception as e:
        logger.error(f"Error cleaning temp directory: {e}")
    
    await message.reply_text("⏹️ Operation cancelled. All temporary files cleaned up.")

@app.on_message(filters.command("seeffmpeg") & filters.private & filters.user(OWNER_ID))
async def show_ffmpeg_command(client: Client, message: Message):
    user_id = message.from_user.id
    user_commands = custom_ffmpeg_commands.get(user_id, {})
    
    response = "<b>Current FFmpeg Commands:</b>\n\n"
    
    for quality in ['480p', '720p', '1080p']:
        response += f"<b>{quality}:</b>\n"
        if quality in user_commands:
            response += f"<code>{user_commands[quality]}</code>\n\n"
        else:
            response += f"<code>{FFMPEG_COMMANDS.get(quality, 'Not set')}</code>\n\n"
    
    response += f"<b>Metadata Command:</b>\n<code>{METADATA_FFMPEG_COMMAND}</code>"
    
    await message.reply_text(response, parse_mode=ParseMode.HTML)

@app.on_message(filters.command("addchnl") & filters.private & filters.user(OWNER_ID))
async def add_force_sub_channel(client: Client, message: Message):
    args = message.text.split()
    if len(args) < 2:
        await message.reply_text("Usage: /addchnl <channel_id>")
        return
    
    try:
        channel_id = int(args[1])
        if channel_id not in force_sub_channels:
            force_sub_channels.append(channel_id)
            await message.reply_text(f"✅ Channel {channel_id} added to force subscription list!")
        else:
            await message.reply_text(f"ℹ️ Channel {channel_id} is already in the force subscription list.")
    except (ValueError, TypeError):
        await message.reply_text("❌ Invalid channel ID format. Please provide a valid channel ID.")
    except Exception as e:
        logger.error(f"Error adding force sub channel: {e}")
        await message.reply_text(f"❌ Error adding channel: {e}")

@app.on_message(filters.command("delchnl") & filters.private & filters.user(OWNER_ID))
async def remove_force_sub_channel(client: Client, message: Message):
    args = message.text.split()
    if len(args) < 2:
        await message.reply_text("Usage: /delchnl <channel_id>")
        return
    
    try:
        channel_id = int(args[1])
        if channel_id in force_sub_channels:
            force_sub_channels.remove(channel_id)
            await message.reply_text(f"✅ Channel {channel_id} removed from force subscription list!")
        else:
            await message.reply_text(f"ℹ️ Channel {channel_id} is not in the force subscription list.")
    except (ValueError, TypeError):
        await message.reply_text("❌ Invalid channel ID format. Please provide a valid channel ID.")
    except Exception as e:
        logger.error(f"Error removing force sub channel: {e}")
        await message.reply_text(f"❌ Error removing channel: {e}")

@app.on_message(filters.command("listchnl") & filters.private & filters.user(OWNER_ID))
async def list_force_sub_channels(client: Client, message: Message):
    if not force_sub_channels:
        await message.reply_text("No force subscription channels configured.")
        return
    
    response = "🔒 Force Subscription Channels:\n\n"
    for channel_id in force_sub_channels:
        try:
            chat = await client.get_chat(channel_id)
            response += f"• {chat.title} (ID: {channel_id})\n"
        except Exception as e:
            response += f"• Channel ID: {channel_id} (Unable to fetch details)\n"
    
    await message.reply_text(response)

@app.on_message(filters.command("cleardata") & filters.private & filters.user(OWNER_ID))
async def clear_temp_data(client: Client, message: Message):
    try:
        # Clear temp directory
        for file in os.listdir("temp"):
            try:
                os.remove(os.path.join("temp", file))
            except Exception as e:
                logger.error(f"Error removing file {file}: {e}")
        
        # Clear caches
        global ani_cache, user_sessions, temp_force_sub_data, cancel_requests
        ani_cache.clear()
        user_sessions.clear()
        temp_force_sub_data.clear()
        cancel_requests.clear()
        
        await message.reply_text("✅ Temporary data and caches cleared!")
    except Exception as e:
        logger.error(f"Error clearing data: {e}")
        await message.reply_text(f"❌ Error clearing data: {e}")

@app.on_message(filters.command("current_channel") & filters.private & filters.user(OWNER_ID))
async def show_current_channel(client: Client, message: Message):
    if current_target_channel:
        try:
            chat = await client.get_chat(current_target_channel)
            await message.reply_text(
                f"✅ Current target channel:\n"
                f"• ID: {current_target_channel}\n"
                f"• Title: {chat.title}\n"
                f"• Username: @{chat.username if chat.username else 'N/A'}"
            )
        except Exception as e:
            await message.reply_text(f"✅ Current target channel: {current_target_channel}\n❌ Error getting chat info: {e}")
    else:
        await message.reply_text("❌ No target channel set. Use /post to set one.")
        
@app.on_message(filters.command("restart") & filters.private & filters.user(OWNER_ID))
async def restart_bot(client: Client, message: Message):
    await message.reply_text("🔄 Restarting bot...")
    os.execl(sys.executable, sys.executable, *sys.argv)

@app.on_callback_query(filters.regex(r"^verify_"))
async def handle_verify_callback(client: Client, callback_query: CallbackQuery):
    user_id = int(callback_query.data.split("_")[1])
    if callback_query.from_user.id != user_id:
        try:
            await callback_query.answer("This is not for you!", show_alert=True)
        except QueryIdInvalid:
            pass
        return
    
    is_subscribed = await check_user_subscription(user_id)
    
    if not is_subscribed:
        try:
            await callback_query.answer("You haven't joined all channels yet!", show_alert=True)
        except QueryIdInvalid:
            pass
        return
    
    try:
        await callback_query.answer("Verification successful! Sending file...")
    except QueryIdInvalid:
        pass
    
    file_data = temp_force_sub_data.get(user_id)
    if not file_data:
        try:
            await callback_query.message.edit_text("Session expired. Please request the file again.")
        except:
            pass
        return
    
    try:
        msg = await client.get_messages(FILE_STORE, message_ids=file_data["msg_id"])
        if msg:
            file_caption = f"<blockquote><b>{msg.caption}</b></blockquote>"
            file_msg = await msg.copy(
                callback_query.message.chat.id, 
                caption=file_caption,
                parse_mode=ParseMode.HTML
            )
            
            warning_text = (
                "<blockquote><b>Tʜɪs Fɪʟᴇ ᴡɪʟʟ ʙᴇ Dᴇʟᴇᴛᴇᴅ ɪɴ 30 mins.</b> "
                "<b>Pʟᴇᴀsᴇ sᴀᴠᴇ ᴏʀ ғᴏʀᴡᴀʀᴅ ɪᴛ ᴛᴏ ʏᴏᴜʀ sᴀᴠᴇᴅ ᴍᴇssᴀɢᴇs "
                "ʙᴇғᴏʀᴇ ɪᴛ ɢᴇᴛs Dᴇʟᴇᴛᴇᴅ.</blockquote>"
            )
            warning_msg = await callback_query.message.reply_text(
                warning_text,
                parse_mode=ParseMode.HTML,
                reply_to_message_id=file_msg.id
            )
            
            message_ids = [file_msg.id, warning_msg.id]
            asyncio.create_task(
                delete_messages_after_delay(callback_query.message.chat.id, message_ids, DELETE_DELAY)
            )
            
            file_messages_to_delete[file_msg.id] = {
                "chat_id": callback_query.message.chat.id,
                "delete_time": asyncio.get_event_loop().time() + DELETE_DELAY
            }
            
            try:
                await callback_query.message.delete()
            except:
                pass
            
            if user_id in temp_force_sub_data:
                del temp_force_sub_data[user_id]
        else:
            try:
                await callback_query.message.edit_text("❌ File not found. It may have been deleted.")
            except:
                pass
    except Exception as e:
        logger.error(f"Error sending file after verification: {e}")
        try:
            await callback_query.message.edit_text("❌ Error retrieving file. Please try again.")
        except:
            pass

@app.on_callback_query(filters.regex(r"^about_bot$"))
async def handle_about_callback(client: Client, callback_query: CallbackQuery):
    try:
        await callback_query.answer()
        # Edit the original message to show about information
        await callback_query.message.edit_caption(
            caption=ABOUT_TEXT,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="back_to_start")]
            ])
        )
    except Exception as e:
        logger.error(f"Error handling about callback: {e}")
        await safe_answer_callback(callback_query, "Error showing information")

@app.on_callback_query(filters.regex(r"^settings$"))
async def handle_settings_callback(client: Client, callback_query: CallbackQuery):
    try:
        await callback_query.answer()
        user_id = callback_query.from_user.id
        bool_metadata = metadata_settings.get(user_id, {}).get("enabled", False)
        multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
        
        user_metadata = metadata_settings.get(user_id, {}).get("code", "")
        
        settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""
        
        buttons = [
            [
                InlineKeyboardButton(
                    'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                    callback_data=f'metadata_{"1" if bool_metadata else "0"}'
                )
            ],
            [
                InlineKeyboardButton(
                    'Queue: ON' if queue_enabled else 'Queue: OFF',
                    callback_data=f'toggle_queue'
                )
            ],
            [
                InlineKeyboardButton(
                    'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                    callback_data=f'toggle_multi_mode'
                )
            ],
            [
                InlineKeyboardButton(
                    'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                    callback_data=f'toggle_update_channel'
                )
            ],
            [
                InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
            ],
            [
                InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="back_to_start")]
        ]
        
        await callback_query.message.edit_caption(
            caption=settings_text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    except Exception as e:
        logger.error(f"Error handling settings callback: {e}")
        await safe_answer_callback(callback_query, "Error showing settings")

@app.on_callback_query(filters.regex("^metadata_"))
async def toggle_metadata_callback(bot: Client, query: CallbackQuery):
    data = query.data
    user_id = query.from_user.id
    
    # Initialize user settings if not exists
    if user_id not in metadata_settings:
        metadata_settings[user_id] = {"enabled": False, "code": ""}
    
    if data.startswith("metadata_"):
        _bool = data.split("_")[1] == '1'
        metadata_settings[user_id]["enabled"] = not _bool
        await query.answer(f"Metadata {'enabled' if not _bool else 'disabled'}")
        
    # Update the message
    bool_metadata = metadata_settings.get(user_id, {}).get("enabled", False)
    multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
    user_metadata = metadata_settings.get(user_id, {}).get("code", "")
    
    settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""
    
    buttons = [
        [
            InlineKeyboardButton(
                'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                callback_data=f'metadata_{"1" if bool_metadata else "0"}'
            )
        ],
        [
            InlineKeyboardButton(
                'Queue: ON' if queue_enabled else 'Queue: OFF',
                callback_data=f'toggle_queue'
            )
        ],
        [
            InlineKeyboardButton(
                'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                callback_data=f'toggle_multi_mode'
            )
        ],
        [
            InlineKeyboardButton(
                'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                callback_data=f'toggle_update_channel'
            )
        ],
        [
            InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
        ],
        [
            InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
        ],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_start")]
    ]
    
    await query.message.edit_caption(
        caption=settings_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons)
    )

@app.on_callback_query(filters.regex("^toggle_queue$"))
async def toggle_queue_callback(bot: Client, query: CallbackQuery):
    global queue_enabled
    if query.from_user.id != OWNER_ID:
        await query.answer("Only the owner can toggle queue status!", show_alert=True)
        return
    
    queue_enabled = not queue_enabled
    await query.answer(f"Queue {'enabled' if queue_enabled else 'disabled'}")
    
    # Update the message
    bool_metadata = metadata_settings.get(query.from_user.id, {}).get("enabled", False)
    multi_mode = multi_mode_settings.get(query.from_user.id, {}).get("enabled", False)
    user_metadata = metadata_settings.get(query.from_user.id, {}).get("code", "")
    
    settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""

    buttons = [
        [
            InlineKeyboardButton(
                'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                callback_data=f'metadata_{"1" if bool_metadata else "0"}'
            )
        ],
        [
            InlineKeyboardButton(
                'Queue: ON' if queue_enabled else 'Queue: OFF',
                callback_data=f'toggle_queue'
            )
        ],
        [
            InlineKeyboardButton(
                'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                callback_data=f'toggle_multi_mode'
            )
        ],
        [
            InlineKeyboardButton(
                'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                callback_data=f'toggle_update_channel'
            )
        ],
        [
            InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
        ],
        [
            InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
        ],
        [
            InlineKeyboardButton("🔙 Back", callback_data="back_to_start")
        ]
    ]

    await query.message.edit_caption(
        caption=settings_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons)
    )

@app.on_callback_query(filters.regex("^toggle_multi_mode$"))
async def toggle_multi_mode_callback(bot: Client, query: CallbackQuery):
    user_id = query.from_user.id
    if user_id != OWNER_ID:
        await query.answer("Only the owner can toggle multi mode!", show_alert=True)
        return
    
    if user_id not in multi_mode_settings:
        multi_mode_settings[user_id] = {"enabled": False, "source_file": None}
    
    multi_mode_settings[user_id]["enabled"] = not multi_mode_settings[user_id]["enabled"]
    await query.answer(f"Multi mode {'enabled' if multi_mode_settings[user_id]['enabled'] else 'disabled'}")
    
    # Update the message
    bool_metadata = metadata_settings.get(user_id, {}).get("enabled", False)
    multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
    user_metadata = metadata_settings.get(user_id, {}).get("code", "")
    
    settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""

    buttons = [
        [
            InlineKeyboardButton(
                'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                callback_data=f'metadata_{"1" if bool_metadata else "0"}'
            )
        ],
        [
            InlineKeyboardButton(
                'Queue: ON' if queue_enabled else 'Queue: OFF',
                callback_data=f'toggle_queue'
            )
        ],
        [
            InlineKeyboardButton(
                'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                callback_data=f'toggle_multi_mode'
            )
        ],
        [
            InlineKeyboardButton(
                'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                callback_data=f'toggle_update_channel'
            )
        ],
        [
            InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
        ],
        [
            InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
        ],
        [
            InlineKeyboardButton("🔙 Back", callback_data="back_to_start")
        ]
    ]

    await query.message.edit_caption(
        caption=settings_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons)
    )

@app.on_callback_query(filters.regex("^toggle_update_channel$"))
async def toggle_update_channel_callback(bot: Client, query: CallbackQuery):
    global UPDATE_CHANNEL_ENABLED
    if query.from_user.id != OWNER_ID:
        await query.answer("Only the owner can toggle update channel status!", show_alert=True)
        return
    
    UPDATE_CHANNEL_ENABLED = not UPDATE_CHANNEL_ENABLED
    await query.answer(f"Update channel {'enabled' if UPDATE_CHANNEL_ENABLED else 'disabled'}")
    
    # Update the message
    bool_metadata = metadata_settings.get(query.from_user.id, {}).get("enabled", False)
    multi_mode = multi_mode_settings.get(query.from_user.id, {}).get("enabled", False)
    user_metadata = metadata_settings.get(query.from_user.id, {}).get("code", "")
    
    settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""

    buttons = [
        [
            InlineKeyboardButton(
                'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                callback_data=f'metadata_{"1" if bool_metadata else "0"}'
            )
        ],
        [
            InlineKeyboardButton(
                'Queue: ON' if queue_enabled else 'Queue: OFF',
                callback_data=f'toggle_queue'
            )
        ],
        [
            InlineKeyboardButton(
                'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                callback_data=f'toggle_multi_mode'
            )
        ],
        [
            InlineKeyboardButton(
                'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                callback_data=f'toggle_update_channel'
            )
        ],
        [
            InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
        ],
        [
            InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
        ],
        [
            InlineKeyboardButton("🔙 Back", callback_data="back_to_start")
        ]
    ]

    await query.message.edit_caption(
        caption=settings_text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons)
    )

@app.on_callback_query(filters.regex("^custom_metadata$"))
async def custom_metadata_callback(bot: Client, query: CallbackQuery):
    user_id = query.from_user.id
    
    # Initialize user settings if not exists
    if user_id not in metadata_settings:
        metadata_settings[user_id] = {"enabled": False, "code": ""}
    
    await query.message.delete()
    try:
        user_metadata = metadata_settings.get(user_id, {}).get("code", "")
        metadata_message = f"""
<b>--Metadata Settings:--</b>

➜ <b>ᴄᴜʀʀᴇɴᴛ ᴍᴇᴛᴀᴅᴀᴛᴀ:</b> `{user_metadata}`

<b>Description</b> : Metadata will be embedded in all video streams including audio and subtitles.

<b>➲ Send metadata title. Timeout: 60 sec</b>
"""

        metadata = await bot.ask(
            chat_id=query.from_user.id,
            text=metadata_message,
            filters=filters.text,
            timeout=60,
            disable_web_page_preview=True,
        )
    except asyncio.TimeoutError:
        await bot.send_message(
            chat_id=query.from_user.id,
            text="⚠️ Error!!\n\n**Request timed out.**\nRestart by using /settings",
        )
        return
    
    try:
        ms = await bot.send_message(
            chat_id=query.from_user.id,
            text="**Wait A Second...**",
            reply_to_message_id=metadata.id
        )
        metadata_settings[user_id]["code"] = metadata.text
        await ms.edit("**Your Metadata Code Set Successfully ✅**")
        
        # Show settings again after setting metadata
        bool_metadata = metadata_settings.get(user_id, {}).get("enabled", False)
        multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
        user_metadata = metadata_settings.get(user_id, {}).get("code", metadata.text)
        
        settings_text = f"""
<b>⚙️ Bot Settings</b>

<b>Metadata Feature:</b> {'✅ Enabled' if bool_metadata else '❌ Disabled'}
<b>Queue System:</b> {'✅ Enabled' if queue_enabled else '❌ Disabled'}
<b>Multi Mode:</b> {'✅ Enabled' if multi_mode else '❌ Disabled'}
<b>Update Channel:</b> {'✅ Enabled' if UPDATE_CHANNEL_ENABLED else '❌ Disabled'}

<b>Your Metadata Code:</b>
<code>{user_metadata}</code>

<b>Target Channel:</b> {TARGET_CHANNEL}
<b>Update Channel:</b> {UPDATE_CHANNEL}
"""
        
        buttons = [
            [
                InlineKeyboardButton(
                    'Metadata: ON' if bool_metadata else 'Metadata: OFF',
                    callback_data=f'metadata_{"1" if bool_metadata else "0"}'
                )
            ],
            [
                InlineKeyboardButton(
                    'Queue: ON' if queue_enabled else 'Queue: OFF',
                    callback_data=f'toggle_queue'
                )
            ],
            [
                InlineKeyboardButton(
                    'Multi Mode: ON' if multi_mode else 'Multi Mode: OFF',
                    callback_data=f'toggle_multi_mode'
                )
            ],
            [
                InlineKeyboardButton(
                    'Update Channel: ON' if UPDATE_CHANNEL_ENABLED else 'Update Channel: OFF',
                    callback_data=f'toggle_update_channel'
                )
            ],
            [
                InlineKeyboardButton('Set Custom Metadata', callback_data='custom_metadata')
            ],
            [
                InlineKeyboardButton('Set FFmpeg Commands', callback_data='ffmpeg_commands')
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="back_to_start")]
        ]
        
        await bot.send_photo(
            user_id,
            photo=START_IMAGE_URL,
            caption=settings_text,
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        await bot.send_message(
            chat_id=query.from_user.id,
            text=f"**Error Occurred:** {str(e)}"
        )

@app.on_callback_query(filters.regex("^ffmpeg_commands$"))
async def ffmpeg_commands_callback(bot: Client, query: CallbackQuery):
    user_id = query.from_user.id
    user_commands = custom_ffmpeg_commands.get(user_id, {})
    
    response = "<b>Current FFmpeg Commands:</b>\n\n"
    
    for quality in ['480p', '720p', '1080p']:
        response += f"<b>{quality}:</b>\n"
        if quality in user_commands:
            response += f"<code>{user_commands[quality]}</code>\n\n"
        else:
            response += f"<code>{FFMPEG_COMMANDS.get(quality, 'Not set')}</code>\n\n"
    
    response += f"<b>Metadata Command:</b>\n<code>{METADATA_FFMPEG_COMMAND}</code>\n\n"
    response += "Use /set1, /set2, /set3 to set custom commands for each quality."
    
    await query.message.edit_caption(
        caption=response,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 Back", callback_data="settings")]
        ])
    )

@app.on_callback_query(filters.regex(r"^back_to_start$"))
async def handle_back_callback(client: Client, callback_query: CallbackQuery):
    try:
        await callback_query.answer()
        user_id = callback_query.from_user.id
        first_name = callback_query.from_user.first_name or "User"
        greeting = f"<blockquote><b>Hey {html.escape(first_name)},</b></blockquote>\n"
        bot_description = "<blockquote><b>𝗂 𝖺𝗆 𝖺 𝖺𝖽𝗏𝖺𝗇𝖼𝖾𝖽 𝗍𝖾𝗅𝖾𝗀𝗋𝖺𝗆 𝖻𝗈𝗍 𝗍𝗁𝖺𝗍 𝖺𝗅𝗅𝗈𝗐𝗌 𝗒𝗈𝗎 𝗍𝗀 𝗒𝗈𝗎𝗋 𝖿𝖺𝗏𝗈𝗋𝗂𝗍𝖾 𝗌𝖾𝗋𝗂𝖾𝗌 𝖺𝗇𝖽 𝖾𝗉𝗂𝗌𝗈𝖽𝖾𝗌 𝖽𝗂𝗋𝖾𝖼𝗍𝗅𝗒</b></blockquote>"
        caption = greeting + bot_description
        
        # Recreate the original buttons
        buttons = [
            [
                InlineKeyboardButton("🔰 Main Channel", url="https://t.me/ATXanime"),
                InlineKeyboardButton("📇 About", callback_data="about_bot")
            ],
            [
                InlineKeyboardButton("👑 Developer", user_id=OWNER_ID)
            ]
        ]
        
        await callback_query.message.edit_caption(
            caption=caption,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    except Exception as e:
        logger.error(f"Error handling back callback: {e}")

@app.on_message(filters.command("post") & filters.private)
async def set_post_channel(client: Client, message: Message):
    global current_target_channel
    
    if message.from_user.id != OWNER_ID:
        await message.reply_text("🚫 Only the owner can set posting channels.")
        return
    
    try:
        channel_id = int(message.command[1])
        user_id = message.from_user.id
        
        # Verify the bot has access to the channel
        if not await verify_channel_access(channel_id):
            await message.reply_text("❌ Bot doesn't have access to this channel. Make sure the bot is added as admin.")
            return
        
        current_target_channel = channel_id
        
        if user_id not in user_sessions:
            user_sessions[user_id] = {
                "state": "waiting_photo",
                "cover_photo": None,
                "videos": {"480p": None, "720p": None, "1080p": None},
                "target_channel": channel_id,
                "language": "Tamil",
                "codec": "HEVC",
                "anilist_data": None
            }
        else:
            user_sessions[user_id]["target_channel"] = channel_id
        
        await message.reply_text(f"✅ Posting channel set to: {channel_id}")
    except (IndexError, ValueError):
        await message.reply_text("❌ Invalid format. Use: /post -10012345678")
    except Exception as e:
        logger.error(f"Error setting channel: {e}")
        await message.reply_text(f"❌ Error setting channel: {e}")

@app.on_message(filters.private & filters.photo)
async def receive_photo(client: Client, message: Message):
    user_id = message.from_user.id
    if user_id != OWNER_ID:
        return
    
    # Reset session when receiving a new photo
    user_sessions[user_id] = {
        "state": "waiting_photo",
        "cover_photo": None,
        "videos": {"480p": None, "720p": None, "1080p": None},
        "target_channel": TARGET_CHANNEL,
        "language": "Tamil",
        "codec": "HEVC",
        "anilist_data": None
    }
    
    session = user_sessions[user_id]
    
    try:
        session["cover_photo"] = message.photo.file_id
        session["state"] = "waiting_videos"
        
        # Check if we're in multi mode
        is_multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
        
        if is_multi_mode:
            await message.reply_text(
                "🖼️ Cover photo received! Now please send one high-quality video file.\n\n"
                "The bot will automatically encode it to 480p, 720p, and 1080p."
            )
        else:
            await message.reply_text(
                "🖼️ Cover photo received! Now please send 3 video files in the following resolutions:\n\n"
                "• One with 480p in filename\n"
                "• One with 720p in filename\n"
                "• One with 1080p in filename\n\n"
                "Note: The resolution can be anywhere in the filename (e.g., [480p], 480p, etc.)"
            )
    except Exception as e:
        logger.error(f"Error processing photo: {e}")
        await message.reply_text("❌ Error processing photo. Please try again.")

@app.on_message(filters.private & (filters.video | filters.document))
async def receive_video(client: Client, message: Message):
    user_id = message.from_user.id
    if user_id != OWNER_ID:
        return
    
    if user_id not in user_sessions:
        user_sessions[user_id] = {
            "state": "waiting_videos",
            "cover_photo": None,
            "videos": {"480p": None, "720p": None, "1080p": None},
            "target_channel": TARGET_CHANNEL,
            "language": "Tamil",
            "codec": "HEVC",
            "anilist_data": None
        }
    
    session = user_sessions[user_id]
    if session["state"] != "waiting_videos":
        return
    
    # Check if we're in multi mode
    is_multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
    
    if is_multi_mode:
        # Multi mode - store the source file and proceed to preview
        multi_mode_settings[user_id]["source_file"] = message
        
        # Get AniList data from filename
        if message.video:
            filename = message.video.file_name if message.video else ""
        elif message.document:
            filename = message.document.file_name if message.document else ""
        else:
            return
            
        editor = TextEditor(filename)
        await editor.load_anilist()
        session["anilist_data"] = editor.adata
        
        await send_preview(client, user_id)
        return
    
    # Normal mode processing
    if message.video:
        filename = message.video.file_name if message.video else ""
    elif message.document:
        filename = message.document.file_name if message.document else ""
    else:
        return
    
    filename_lower = filename.lower()
    if '480p' in filename_lower:
        quality = '480p'
    elif '720p' in filename_lower:
        quality = '720p'
    elif '1080p' in filename_lower:
        quality = '1080p'
    else:
        # Try to extract from brackets
        match = re.search(r'\[(\d{3,4}p)\]', filename, re.IGNORECASE)
        if match:
            quality = match.group(1).lower()
        else:
            await message.reply_text(
                "❌ Couldn't find resolution in filename! Filename must contain one of: 480p, 720p, or 1080p.\n"
                "Please resend with proper naming.\n\n"
                f"Your filename: {filename[:50]}..."
            )
            return
    
    session["videos"][quality] = message
    
    # Get formatted name for feedback
    if session["anilist_data"] is None:
        # First video - get AniList data
        editor = TextEditor(filename)
        await editor.load_anilist()
        session["anilist_data"] = editor.adata
    else:
        # Reuse existing AniList data
        editor = TextEditor(filename)
        editor.adata = session["anilist_data"]
    
    # Display name without brand
    formatted_name = await editor.get_formatted_name(quality, include_brand=False)
    
    if len(formatted_name) > 50:
        display_name = formatted_name[:47] + "..."
    else:
        display_name = formatted_name
    
    videos = session["videos"]
    if all(videos.values()):
        await send_preview(client, user_id)
    else:
        missing = [q for q, v in videos.items() if not v]
        await message.reply_text(
            f"✅ Received {quality} video!\n"
            f"• Name: {display_name}\n\n"
            f"Still waiting for: {', '.join(missing)}"
        )

async def send_preview(client: Client, user_id: int):
    session = user_sessions[user_id]
    session["state"] = "waiting_confirmation"
    
    # Check if we're in multi mode
    is_multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
    source_file = multi_mode_settings.get(user_id, {}).get("source_file")
    
    if is_multi_mode and source_file:
        # Multi mode preview
        filename = source_file.video.file_name if source_file.video else source_file.document.file_name
    else:
        # Normal mode preview
        video_msg = next(v for v in session["videos"].values() if v)
        filename = video_msg.video.file_name if video_msg.video else video_msg.document.file_name
    
    # Reuse AniList data from session
    editor = TextEditor(filename)
    editor.adata = session["anilist_data"]
    
    # Get formatted names for all qualities (without brand for preview)
    formatted_names = {}
    for quality in ['480p', '720p', '1080p']:
        formatted_names[quality] = await editor.get_formatted_name(quality, include_brand=False)
    
    # Use new caption format
    caption = await editor.get_caption(
        session['language'], 
        session['codec'], 
        "480p, 720p, 1080p"
    ) or f"<blockquote><b>➤ {await editor.get_title()}</b></blockquote>\n" + \
        "<b>────────────────</b>\n" + \
        f"<b>‣ Language :</b> {session['language']}\n" + \
        f"<b>‣ Codec :</b> {session['codec']}\n" + \
        f"<b>‣ Quality :</b> 480p, 720p, 1080p\n" + \
        "<b>────────────────</b>"
    
    # Create preview text with formatted filenames (without brand)
    preview_text = (
        f"<b>📁 File Names Preview:</b>\n\n"
        f"• <b>480p</b>: {formatted_names['480p']}\n"
        f"• <b>720p</b>: {formatted_names['720p']}\n"
        f"• <b>1080p</b>: {formatted_names['1080p']}\n\n"
        f"{caption}"
    )
    
    buttons = [
        [
            InlineKeyboardButton("480p", callback_data="preview_480p"),
            InlineKeyboardButton("720p", callback_data="preview_720p"),
        ],
        [
            InlineKeyboardButton("1080p", callback_data="preview_1080p"),
        ],
        [
            InlineKeyboardButton("✅ Send", callback_data="confirm_send"),
            InlineKeyboardButton("❌ Cancel", callback_data="confirm_cancel"),
        ]
    ]
    
    try:
        await client.send_photo(
            chat_id=user_id,
            photo=session["cover_photo"],
            caption=preview_text,
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Error sending preview: {e}")
        await client.send_message(user_id, "❌ Error generating preview. Please try again.")

async def verify_channel_access(channel_id: int) -> bool:
    try:
        await app.get_chat(channel_id)
        return True
    except (PeerIdInvalid, ChannelInvalid):
        return False
    except Exception as e:
        logger.error(f"Error verifying channel access: {e}")
        return False

@app.on_callback_query()
async def handle_callback(client: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    data = callback_query.data
    
    if data.startswith("preview_"):
        quality = data.split("_")[1]
        await safe_answer_callback(callback_query, f"{quality.upper()} preview - Press SEND to publish", show_alert=True)
        return
    
    if data == "confirm_cancel":
        if user_id in user_sessions:
            del user_sessions[user_id]
        if user_id in multi_mode_settings:
            multi_mode_settings[user_id] = {"enabled": multi_mode_settings[user_id]["enabled"], "source_file": None}
        try:
            await callback_query.message.delete()
        except:
            pass
        await safe_answer_callback(callback_query, "Operation cancelled")
        await client.send_message(user_id, "❌ Process cancelled. Start again with /start")
        return
    
    if data == "confirm_send":
        if user_id != OWNER_ID or user_id not in user_sessions:
            await safe_answer_callback(callback_query, "Session expired or unauthorized! Start again with /start")
            return
        
        # FIX: Answer callback immediately to prevent QueryIdInvalid
        try:
            await callback_query.answer("Processing started...")
        except QueryIdInvalid:
            logger.warning("QueryIdInvalid when answering confirm_send")
        
        # Get current multi-mode settings
        is_multi_mode = multi_mode_settings.get(user_id, {}).get("enabled", False)
        source_file = multi_mode_settings.get(user_id, {}).get("source_file")
        
        # Create task dictionary with ALL necessary data
        task = {
            "session": user_sessions[user_id],
            "callback_query": callback_query,
            "user_id": user_id,
            "is_multi_mode": is_multi_mode,
            "source_file": source_file  # Include source file in task data
        }
        
        # Add to queue if enabled
        if queue_enabled:
            await encoding_queue.put(task)
            await client.send_message(user_id, "✅ Task added to processing queue. You'll be notified when processing starts.")
        else:
            # Process immediately
            async with processing_lock:
                try:
                    await process_task(task)
                except Exception as e:
                    logger.error(f"Error processing task: {traceback.format_exc()}")
                    await client.send_message(user_id, f"❌ Error during processing: {str(e)[:300]}")

@app.on_message(filters.command("queue_status") & filters.private & filters.user(OWNER_ID))
async def show_queue_status(client: Client, message: Message):
    queue_size = encoding_queue.qsize()
    status = f"📊 Queue Status:\n\n• Tasks in queue: {queue_size}\n• Active processes: {active_encodings}"
    await message.reply_text(status)

@app.on_message(filters.command("clear_queue") & filters.private & filters.user(OWNER_ID))
async def clear_encoding_queue_command(client: Client, message: Message):
    global encoding_queue
    
    # Create a new empty queue
    new_queue = asyncio.Queue()
    
    # Count how many tasks were cleared
    count = 0
    while not encoding_queue.empty():
        try:
            encoding_queue.get_nowait()
            encoding_queue.task_done()
            count += 1
        except asyncio.QueueEmpty:
            break
    
    # Replace the old queue with the new empty one
    encoding_queue = new_queue
    
    await message.reply_text(f"✅ Processing queue cleared! Removed {count} pending tasks.")

async def startup_checks():
    logger.info("Running startup checks...")
    
    # Create persistent invite links
    try:
        if current_target_channel:
            await create_persistent_invite_link(current_target_channel)
            logger.info(f"Target channel invite link created for {current_target_channel}")
    except Exception as e:
        logger.error(f"Error creating target channel invite link: {e}")
    
    try:
        await create_persistent_invite_link(UPDATE_CHANNEL)
        logger.info(f"Update channel invite link created")
    except Exception as e:
        logger.error(f"Error creating update channel invite link: {e}")
    
    logger.info(f"DB_CHANNEL: {DB_CHANNEL}")
    if not await verify_channel_access(DB_CHANNEL):
        logger.error("❌ Bot not in DB_CHANNEL or lacks permissions!")
    
    if current_target_channel and not await verify_channel_access(current_target_channel):
        logger.error(f"❌ Bot not in target channel {current_target_channel} or lacks permissions!")
    
    logger.info(f"UPDATE_CHANNEL: {UPDATE_CHANNEL}")
    if not await verify_channel_access(UPDATE_CHANNEL):
        logger.error("❌ Bot not in UPDATE_CHANNEL or lacks permissions!")
    
    if await verify_channel_access(DB_CHANNEL) and \
       (not current_target_channel or await verify_channel_access(current_target_channel)) and \
       await verify_channel_access(UPDATE_CHANNEL):
        logger.info("✅ All channel access verified!")
    else:
        logger.error("❌ FIX REQUIRED: Add bot as admin to all channels with permissions")
    
    try:
        ffmpeg_version = subprocess.check_output(['ffmpeg', '-version'], stderr=subprocess.STDOUT, text=True)
        logger.info("✅ FFmpeg found:\n" + ffmpeg_version.split('\n')[0])
    except Exception as e:
        logger.error(f"❌ FFmpeg not found: {str(e)}")
    
    me = await app.get_me()
    logger.info(f"🤖 Bot username: @{me.username}")
    logger.info("🚀 Startup checks completed")

if __name__ == "__main__":
    import sys
    os.makedirs("temp", exist_ok=True)
    
    # Clean temp directory
    for file in os.listdir("temp"):
        try:
            os.remove(os.path.join("temp", file))
        except:
            pass
    
    # Start the client
    app.start()
    
    # Get the event loop
    loop = asyncio.get_event_loop()
    
    # Run startup checks
    loop.run_until_complete(startup_checks())
    
    # Start queue manager
    for _ in range(MAX_CONCURRENT_ENCODINGS):
        loop.create_task(process_queue_manager())
    
    logger.info("✅ Bot started successfully")
    idle()
    app.stop()
